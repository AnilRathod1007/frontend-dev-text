import React, { useState } from "react";
import "../common/CustomDropdown.css";

const CustomDropdown = ({ options, onCheckboxChange }) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [selectedCheckboxes, setSelectedCheckboxes] = useState([]);
  const [showChildren, setShowChildren] = useState({});

  const toggleDropdown = () => {
    setDropdownOpen(!dropdownOpen);
  };

  const handleParentCheckboxChange = (value, checked) => {
    const updatedShowChildren = { ...showChildren };
    updatedShowChildren[value] = checked;
    setShowChildren(updatedShowChildren);

    const updatedSelectedCheckboxes = checked
      ? [...selectedCheckboxes, value]
      : selectedCheckboxes.filter((item) => item !== value);

    setSelectedCheckboxes(updatedSelectedCheckboxes);

    if (onCheckboxChange) {
      onCheckboxChange(updatedSelectedCheckboxes);
    }
  };

  const handleChildCheckboxChange = (value, checked) => {
    const updatedSelectedCheckboxes = checked
      ? [...selectedCheckboxes, value]
      : selectedCheckboxes.filter((item) => item !== value);

    setSelectedCheckboxes(updatedSelectedCheckboxes);

    if (onCheckboxChange) {
      onCheckboxChange(updatedSelectedCheckboxes);
    }
  };

  return (
    <div className="dropdown-checkbox">
      <button onClick={toggleDropdown}>Toggle Dropdown</button>
      {dropdownOpen && (
        <div className="dropdown-content">
          {options.map((option) => (
            <div key={option.value}>
              <label>
                <input
                  type="checkbox"
                  value={option.value}
                  checked={selectedCheckboxes.includes(option.value)}
                  onChange={(e) =>
                    handleParentCheckboxChange(option.value, e.target.checked)
                  }
                />
                {option.label}
              </label>
              {showChildren[option.value] && option.children && (
                <div className="children">
                  {option.children.map((child) => (
                    <label key={child.value}>
                      <input
                        type="checkbox"
                        value={child.value}
                        checked={selectedCheckboxes.includes(child.value)}
                        onChange={(e) =>
                          handleChildCheckboxChange(
                            child.value,
                            e.target.checked
                          )
                        }
                      />
                      {child.label}
                    </label>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default CustomDropdown;
