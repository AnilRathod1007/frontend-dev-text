const baseUrl = "https://b6e8-103-116-10-72.ngrok-free.app";
export default baseUrl;
