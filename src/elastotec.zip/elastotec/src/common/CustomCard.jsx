import React, { useEffect, useState } from "react";
import { PlusCircleOutlined } from "@ant-design/icons";
import { Button, Card, Col, Row } from "antd";
import illustration_and_text from "src/assets/illustration_and_text.png";

const CustomCard = ({
  name,
  onClick,
  onClickCard,
  buttonName,
  data,
  selectedDataId,
  setSelectedDataId,
}) => {
  // console.log(data, "card");
  const [isHovered, setIsHovered] = useState(false);

  return (
    <>
      <Card
        title={
          <Row
            style={{
              color: "white",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              padding: "0px",
            }}
          >
            <Col>{name}</Col>
            <Col>
              <Button
                type="link"
                style={{ color: "#F52247" }}
                onClick={onClick}
              >
                <PlusCircleOutlined /> <span>{buttonName}</span>
              </Button>
            </Col>
          </Row>
        }
        bordered={false}
        style={{
          boxShadow: "0px 0px 80px #00000029",
          height: "100%",
        }}
        headStyle={{ backgroundColor: "#070E03" }}
        bodyStyle={{ padding: "1rem" }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <div
          style={{ height: "58vh", overflow: isHovered ? "auto" : "hidden" }}
        >
          {data?.length > 0 ? (
            data?.map((item, inx) => (
              <div
                key={inx}
                style={{
                  border:
                    item?.PROJECT_ID === selectedDataId ||
                    item?.CONVEYOR_ID === selectedDataId ||
                    item?.PULLEY_ID === selectedDataId
                      ? "1px solid #F52247"
                      : null,
                  borderRadius: "8px",
                  padding: "10px",
                  marginBottom: "10px",
                  cursor: "pointer",
                }}
                onClick={() => {
                  onClickCard(item);
                }}
              >
                <div>
                  {item?.PROJECT_NAME || item?.CONVEYOR_ID || item?.PULLEY_ID}
                </div>
                <div>{item?.PROJECT_LOCATION || item?.PULLEY_LOCATION}</div>
                <div>{item?.LAGGING_REPLACEMENT}</div>
              </div>
            ))
          ) : (
            <>
              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  height: "58vh",
                  overflow: "auto",
                }}
              >
                <img
                  src={illustration_and_text}
                  alt="No Data"
                  style={{ width: "14vw" }}
                />
              </div>
            </>
          )}
        </div>
      </Card>
    </>
  );
};

export default CustomCard;
