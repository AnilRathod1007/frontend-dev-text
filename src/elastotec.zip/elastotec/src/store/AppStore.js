import StoreService from "./StoreServices";
const state = {
  loading: false,
  login: {},
  token: {},
  projectId: null,
  conveyorId: null,
  pulleyId: null,
  simulate: [],
  lagging: [],
  projectName: null,
};

export default StoreService(state);
