import { FilterOutlined } from "@ant-design/icons";
import { Input, Button } from "antd";
import React from "react";
import CustomSearchInput from "src/common/CustomSearchInput";
import filterIcon from "src/assets/filter_icon.png";
import "../project/Project.css";
const { Search } = Input;

const ProjectHeader = ({ onSearch, onClick }) => {
  return (
    <div className="project-header">
      <div className="project-title">Explorer</div>
      <div className="project-details">
        <div className="last-analysis">
          Last analysis performed by username on, 30-03-2023, 11:59 PM
        </div>
        <div className="filter-icon">
          <img src={filterIcon} height={16} alt="Filter Icon" />
        </div>
        <div className="search-input">
          <CustomSearchInput />
        </div>
        {/* <div className="analyse-button">
          <Button
            type="primary"
            style={{
              backgroundColor: "#F52247",
            }}
            onClick={onClick}
          >
            ANALYSE
          </Button>
        </div> */}
      </div>
    </div>
  );
};

export default ProjectHeader;

// import { FilterOutlined } from "@ant-design/icons";
// import { Input, Button } from "antd";
// import React from "react";
// import CustomSearchInput from "src/common/CustomSearchInput";
// import filterIcon from "src/assets/filter_icon.png";
// const { Search } = Input;

// const ProjectHeader = ({ onSearch, onClick }) => {
//   return (
//     <>
//       <div
//         style={{
//           display: "flex",
//           justifyContent: "space-between",
//           padding: "10px 0px",
//           alignItems: "center",
//         }}
//       >
//         <div style={{ fontWeight: "bold", fontSize: "1.4rem" }}>Explorer</div>
//         <div
//           style={{
//             display: "flex",
//             justifyContent: "space-between",
//             alignItems: "center",
//           }}
//         >
//           <div style={{ color: "#F52247", marginRight: "10px" }}>
//             Last analysis performed by username on, 30-03-2023, 11:59 PM
//           </div>
//           <div
//             style={{
//               marginRight: "10px",
//               backgroundColor: "#FFF",
//               boxShadow: "0px 0px 80px #00000029",
//               display: "inline-block",
//               padding: "6px",
//             }}
//           >
//             <img src={filterIcon} height={16} />
//           </div>
//           <div>
//             <CustomSearchInput />
//           </div>
//           <div
//             style={{
//               marginLeft: "10px",
//             }}
//           >
//             {/* <Button
//               type="primary"
//               style={{
//                 backgroundColor: "#F52247",
//               }}
//               onClick={onClick}
//             >
//               ANALYSE
//             </Button> */}
//           </div>
//         </div>
//       </div>
//     </>
//   );
// };

// export default ProjectHeader;
