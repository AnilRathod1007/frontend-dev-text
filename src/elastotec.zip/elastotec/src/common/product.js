export const FrictCoef = {
  WetDirty: {
    FullCeramic: {
      A: -0.0006,
      B: 0.885,
      C: -31.059,
      Lim: 700,
      Asm: 300,
      Euler: 0.35,
    },

    MedCeramic: {
      A: -0.0008,
      B: 0.8269,
      C: -0.0164,
      Lim: 500,
      Asm: 215,
      Euler: 0.35,
    },

    DiamondCeramic: {
      A: -0.0004,
      B: 0.5944,
      C: 3.5048,
      Lim: 700,
      Asm: 260,
      Euler: 0.35,
    },

    DiamondRubber: {
      A: -0.0005,
      B: 0.6261,
      C: -7.4151,
      Lim: 600,
      Asm: 190,
      Euler: 0.3,
    },
  },

  DryClean: {
    FullCeramic: {
      A: -0.0011,
      B: 1.3648,
      C: -48.675,
      Lim: 620,
      Asm: 380,
      Euler: 0.35,
    },

    MedCeramic: {
      A: -0.0015,
      B: 1.3917,
      C: -23.497,
      Lim: 500,
      Asm: 310,
      Euler: 0.35,
    },

    DiamondCeramic: {
      A: -0.0007,
      B: 0.8981,
      C: 17.822,
      Lim: 700,
      Asm: 320,
      Euler: 0.35,
    },

    DiamondRubber: {
      A: -0.0011,
      B: 0.9731,
      C: 9.7147,
      Lim: 480,
      Asm: 230,
      Euler: 0.3,
    },

    PlainRubber: {
      A: -0.0011,
      B: 1.0509,
      C: 17.393,
      Lim: 500,
      Asm: 265,
      Euler: 0.3,
    },
  },
};

export const SN = {
  A: 3789055679467.87,
  B: 4.03662762000801,
  D: 0.0,
  N: 0.417182248985376,
};

export const ProductsDB = [
  {
    Product: "Elastotec Diamond Rubber",
    Thk: 25,
    Duro: 65,
    Material: "DiamondRubber",
    ShearMod: 0.965,
    ContFaceLim: [91, 135, 152.7, 149.7, 141.9, 129.9, 124.7, 0, 0, 0, 0],
    TreadRootLim: [143.9, 108.7, 78.4, 39, 0, 0, 0, 0, 0, 0, 0],
    PullShellLim: [349.1, 335.3, 321, 311, 296.1, 295.9, 271.2, 0, 0, 0, 0],
    TileBondLim: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  },

  {
    Product: "Elastotec Diamond Rubber",
    Thk: 30,
    Duro: 50,
    Material: "DiamondRubber",
    ShearMod: 0.575,
    ContFaceLim: [
      101.7602196, 148.5, 143.4, 129, 115.9, 108.9, 103.7, 0, 0, 0, 0,
    ],
    TreadRootLim: [232.8, 104.8, 75.5, 49.3, 16.5, 0, 0, 0, 0, 0, 0],
    PullShellLim: [364.3, 312.6, 305.4, 273.9, 259.4, 235.5, 224.8, 0, 0, 0, 0],
    TileBondLim: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  },

  {
    Product: "Elastotec Diamond Rubber",
    Thk: 25,
    Duro: 50,
    Material: "DiamondRubber",
    ShearMod: 0.552,
    ContFaceLim: [
      119.8912108, 158.1, 142.1, 125.4, 114, 104.3, 99.3, 0, 0, 0, 0,
    ],
    TreadRootLim: [195, 131.1, 110.6, 78.1, 42.6, 10.5, 0, 0, 0, 0, 0],
    PullShellLim: [356.2, 338.3, 324, 311.4, 292.8, 306.9, 255, 0, 0, 0, 0],
    TileBondLim: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  },

  {
    Product: "Elastotec Diamond Rubber",
    Thk: 12,
    Duro: 65,
    Material: "DiamondRubber",
    ShearMod: 0.892,
    ContFaceLim: [157.8, 160.1, 162.4, 148.6, 153.1, 137.3, 136.3, 0, 0, 0, 0],
    TreadRootLim: [235.4, 211.3, 198.3, 171.5, 138.5, 101.8, 73.3, 0, 0, 0, 0],
    PullShellLim: [334, 311, 298, 282, 267, 253, 217, 0, 0, 0, 0],
    TileBondLim: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  },

  {
    Product: "Hand Cut Diamond Rubber 300x105x5",
    Thk: 15,
    Duro: 65,
    Material: "DiamondRubber",
    ShearMod: 1.386,
    ContFaceLim: [366.4, 354, 336.9, 327.2, 304.1, 287.6, 283.5, 0, 0, 0, 0],
    TreadRootLim: [331.3, 310.9, 292.2, 273.1, 253.1, 234.5, 213.3, 0, 0, 0, 0],
    PullShellLim: [430, 410, 408, 410, 401, 410, 385, 0, 0, 0, 0],
    TileBondLim: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  },

  {
    Product: "HC Diamond Rubber 90x50x10",
    Thk: 25,
    Duro: 65,
    Material: "DiamondRubber",
    ShearMod: 1.188,
    ContFaceLim: [
      190.3, 214.3, 232, 271.3, 280.7, 292.8, 297.5, 259.6, 233.1, 206.9, 180,
    ],
    TreadRootLim: [
      307.4, 293.9, 275, 233.9, 199.9, 167.6, 140.8, 74.3, 13.5, 0, 0,
    ],
    PullShellLim: [
      414, 412, 409, 405, 399, 394, 388, 378, 364.4299659, 359.4309051,
      350.3757395,
    ],
    TileBondLim: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  },

  {
    Product: "Herringbone Rubber 150x8",
    Thk: 25,
    Duro: 60,
    Material: "PlainRubber",
    ShearMod: 1.177,
    ContFaceLim: [0, 274.1, 343.5, 351.8, 370.8, 348.1, 318.2, 0, 0, 0, 0],
    TreadRootLim: [0, 195.4, 170, 122, 78.7, 36.5, 0, 0, 0, 0, 0],
    PullShellLim: [0, 430, 437, 435, 432, 426, 420, 0, 0, 0, 0],
    TileBondLim: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  },

  {
    Product: "Elastotec HTB Rubber",
    Thk: 25,
    Duro: 65,
    Material: "DiamondRubber",
    ShearMod: 1.11,
    ContFaceLim: [98, 156.3, 172.5, 139.9, 130.3, 117.6, 87.8, 0, 0, 0, 0],
    TreadRootLim: [240.2, 241.9, 144.8, 95, 57.9, 44.1, 0, 0, 0, 0, 0],
    PullShellLim: [392, 387, 386, 359, 372, 374, 359, 0, 0, 0, 0],
    TileBondLim: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  },

  {
    Product: "Elastotec Extreme Rubber",
    Thk: 16,
    Duro: 65,
    Material: "DiamondRubber",
    ShearMod: 1.123,
    ContFaceLim: [97.8, 140.4, 143.1, 143.6, 137.1, 123, 99.3, 0, 0, 0, 0],
    TreadRootLim: [206.4, 217.1, 187.8, 148, 109.7, 65.5, 32, 0, 0, 0, 0],
    PullShellLim: [337, 362, 364, 357, 349, 345, 335, 0, 0, 0, 0],
    TileBondLim: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  },

  {
    Product: "Elastotec Extreme Rubber",
    Thk: 25,
    Duro: 65,
    Material: "DiamondRubber",
    ShearMod: 0.803,
    ContFaceLim: [
      100.1, 158.1, 182.4, 184.5, 184.5, 171.6, 169.5, 166, 161.5, 147, 132.2,
    ],
    TreadRootLim: [368.7, 228.8, 168.5, 124.3, 83.1, 49.5, 9.7, 5, 0, 0, 0],
    PullShellLim: [422, 311, 305, 281, 252, 229, 212, 175, 139, 93, 48],
    TileBondLim: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  },

  {
    Product: "Elastotec 15% Ceramic Diamond",
    Thk: 25,
    Duro: 65,
    Material: "DiamondCeramic",
    ShearMod: 0.757,
    ContFaceLim: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    TreadRootLim: [91.1, 66.7, 63.3, 38.6, 18.8, 0, 0, 0, 0, 0, 0],
    PullShellLim: [161, 159, 188, 193, 192, 179, 177, 0, 0, 0, 0],
    TileBondLim: [86.6, 95, 123.1, 132.5, 125.5, 113.7, 108.1, 0, 0, 0, 0],
  },

  {
    Product: "Elastotec 15% Ceramic Diamond",
    Thk: 12,
    Duro: 65,
    Material: "DiamondCeramic",
    ShearMod: 0.492,
    ContFaceLim: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    TreadRootLim: [91.1, 81.2, 75, 79.6, 99.8, 106.1, 106.3, 0, 0, 0, 0],
    PullShellLim: [115, 77, 28, 1, 0, 0, 0, 0, 0, 0, 0],
    TileBondLim: [76.7, 57.3, 37.6, 30.1, 18.5, 0.9, 0, 0, 0, 0, 0],
  },

  {
    Product: "Elastotec 20% Ceramic Dimpled",
    Thk: 12,
    Duro: 65,
    Material: "DiamondCeramic",
    ShearMod: 0.627,
    ContFaceLim: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    TreadRootLim: [159, 148.7, 128.8, 117.3, 111.3, 100.8, 0, 0, 0, 0, 0],
    PullShellLim: [232, 203, 149, 97, 48, 7, 0, 0, 0, 0, 0],
    TileBondLim: [137.7, 120.1, 100.5, 81.3, 70.3, 53.2, 39.3, 0, 0, 0, 0],
  },

  {
    Product: "Elastotec 20% Ceramic Dimpled",
    Thk: 25,
    Duro: 65,
    Material: "DiamondCeramic",
    ShearMod: 0.418,
    ContFaceLim: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    TreadRootLim: [129.4, 99.7, 63.1, 64.8, 37.4, 6.3, 0, 0, 0, 0, 0],
    PullShellLim: [233, 307, 259, 242, 250, 251, 253, 0, 0, 0, 0],
    TileBondLim: [129.4, 141.5, 136.5, 154.4, 171, 174.2, 182.2, 0, 0, 0, 0],
  },

  {
    Product: "Elastotec 38% Ceramic Smooth",
    Thk: 12,
    Duro: 65,
    Material: "MedCeramic",
    ShearMod: 1.866,
    ContFaceLim: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    TreadRootLim: [338.2, 340.5, 317.7, 315.8, 308.4, 302.8, 291.1, 0, 0, 0, 0],
    PullShellLim: [422, 398, 393, 368, 368, 355, 339, 0, 0, 0, 0],
    TileBondLim: [317.9, 313, 290.6, 270.2, 238.8, 219.1, 189.2, 0, 0, 0, 0],
  },

  {
    Product: "Elastotec 38% Ceramic Dimpled",
    Thk: 12,
    Duro: 65,
    Material: "MedCeramic",
    ShearMod: 1.589,
    ContFaceLim: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    TreadRootLim: [
      276.7, 262.4, 238, 206.3, 190.4, 170.9, 156.9, 134, 105.1, 0, 0,
    ],
    PullShellLim: [401, 395, 379, 357, 342, 327, 307, 286, 249, 0, 0],
    TileBondLim: [233.6, 229.1, 226.4, 206.3, 160.4, 109.3, 66.7, 1.2, 0, 0, 0],
  },

  {
    Product: "Elastotec 38% Ceramic Dimpled",
    Thk: 25,
    Duro: 65,
    Material: "MedCeramic",
    ShearMod: 1.38,
    ContFaceLim: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    TreadRootLim: [
      255.7, 241.3, 213.6, 182.5, 158.4, 118.3, 88, 33.2, 1.3, 0, 0,
    ],
    PullShellLim: [421, 414, 418, 418, 417, 407, 402, 394, 382, 0, 0],
    TileBondLim: [
      255.7, 235.4, 225.8, 201.9, 166.2, 144.9, 123.3, 83.9, 43.5, 0, 0,
    ],
  },

  {
    Product: "Elastotec 38% Ceramic Dimpled",
    Thk: 25,
    Duro: 60,
    Material: "MedCeramic",
    ShearMod: 1.152,
    ContFaceLim: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    TreadRootLim: [
      259.3, 250.2, 211.3, 185.9, 161.5, 126.8, 90.4, 37.3, 1.2, 0, 0,
    ],
    PullShellLim: [422, 421, 419, 414, 409, 404, 399, 392, 389, 0, 0],
    TileBondLim: [
      255.5, 250.2, 217.6, 192.5, 168.4, 141.9, 119.2, 73.3, 38.1, 0, 0,
    ],
  },

  {
    Product: "Elastotec 80% Ceramic Smooth",
    Thk: 12,
    Duro: 65,
    Material: "FullCeramic",
    ShearMod: 2.173,
    ContFaceLim: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    TreadRootLim: [360, 349, 335, 326, 312, 308, 275, 0, 0, 0, 0],
    PullShellLim: [468, 467, 452, 444, 434, 423, 415, 0, 0, 0, 0],
    TileBondLim: [292.6, 289, 279.5, 280.2, 278.3, 280.5, 320.6, 0, 0, 0, 0],
  },

  {
    Product: "Elastotec 80% Ceramic Dimpled",
    Thk: 12,
    Duro: 65,
    Material: "FullCeramic",
    ShearMod: 2.336,
    ContFaceLim: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    TreadRootLim: [317, 306, 291, 279, 252, 237, 222, 167, 129, 69, 0],
    PullShellLim: [449, 442, 442, 435, 424, 411, 400, 355, 340, 320, 305],
    TileBondLim: [
      384.8, 367.5, 360.9, 347.9, 330.6, 313.5, 283.2, 208.9, 144.1, 98.6, 69,
    ],
  },

  {
    Product: "Elastotec 80% Ceramic Dimpled",
    Thk: 25,
    Duro: 65,
    Material: "FullCeramic",
    ShearMod: 1.562,
    ContFaceLim: [null, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    TreadRootLim: [318, 295, 262, 232, 198, 169, 145, 66, 0, 0, 0],
    PullShellLim: [427, 432, 433, 434, 437, 436, 431, 431, 432, 428, 420],
    TileBondLim: [
      376.4, 367.6, 352.7, 325.3, 302.6, 269.6, 239.8, 190, 146.1, 85.2, 40.4,
    ],
  },

  {
    Product: "Elastotec 80% Ceramic Extreme",
    Thk: 25,
    Duro: 65,
    Material: "FullCeramic",
    ShearMod: 1.843,
    ContFaceLim: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    TreadRootLim: [359, 370, 365, 362, 353, 347, 340, 333, 320, 311, 295.2],
    PullShellLim: [446, 440, 441, 444, 441, 442, 442, 443, 440, 437.7, 435],
    TileBondLim: [
      463.4, 460.2, 459.6, 462.7, 459.8, 460.4, 458.7, 451.8, 453.9, 453.3,
      453.3,
    ],
  },

  {
    Product: "Direct Bond Dimpled",
    Thk: 6,
    Duro: 0,
    Material: "FullCeramic",
    ShearMod: 1932,
    ContFaceLim: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    TreadRootLim: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    PullShellLim: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    TileBondLim: [547, 546.6, 547.9, 550.2, 552.9, 543, 537.6, 0, 0, 0, 506],
  },

  {
    Product: "Direct Bond Smooth",
    Thk: 6,
    Duro: 0,
    Material: "FullCeramic",
    ShearMod: 5268,
    ContFaceLim: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    TreadRootLim: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    PullShellLim: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    TileBondLim: [333.6, 398.1, 428.5, 434.3, 424.9, 419.1, 418, 0, 0, 0, 0],
  },
];
