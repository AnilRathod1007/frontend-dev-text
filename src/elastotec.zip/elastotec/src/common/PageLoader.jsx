import { LoadingOutlined } from "@ant-design/icons";
import Modal from "antd/lib/modal/Modal";
import React from "react";
import "../common/PageLoader.css";
function PageLoader({ visible = false }) {
  return (
    <Modal
      className="loadingModal"
      mask={false}
      open={visible}
      footer={null}
      centered={true}
      closable={false}
      transitionName=""
    >
      <div
        className="r-c-c"
        style={{
          display: "flex",
          flexDirection: "row-reverse",
          justifyContent: "center",
          alignItems: "center",
          backgroundColor: "rgba(0, 0, 0, 0.5)",
          width: 60,
          height: 60,
          borderRadius: 30,
          marginLeft: "50%",
        }}
      >
        <LoadingOutlined style={{ fontSize: 24, color: "white" }} />
      </div>
    </Modal>
  );
}
export default PageLoader;
