import {
  Card,
  Col,
  Form,
  Row,
  Radio,
  Input,
  Button,
  Space,
  TreeSelect,
  Cascader,
  Modal,
} from "antd";
import React, { useEffect, useRef, useState } from "react";
import axios from "axios";
import "../analyes/Styles.css";
import NewLagging from "./NewLagging";
import AppStore from "src/store/AppStore";
import Notification from "src/services/Notification";
import baseUrl from "src/common/baseUrl";
import { useLocation } from "react-router-dom";

import { ProductsDB, SN, FrictCoef } from "src/common/product";
import PageLoader from "src/common/PageLoader";

const { SHOW_PARENT } = TreeSelect;

const LaggingOperating = ({
  current,
  setCurrent,
  laggingInputData,
  setLaggingInputData,
  simulateOutput,
  setSimulateOutput,
}) => {
  const [form] = Form.useForm();
  const location = useLocation();

  const [loginToken, setLoginToken] = AppStore("token");
  const [selectedPulleyId, setSelectedPulleyId] = AppStore("pulleyId");
  const [projectName, setProjectName] = AppStore("projectName");
  const [selectedProjectId, setSelectedProjectId] = AppStore("projectId");
  const [selectedConveyorId, setSelectedConveyorId] = AppStore("conveyorId");

  const [open, setOpen] = useState(false);
  const [workingCondition, setWorkingCondition] = useState(null);
  const [laggingContact, setLaggingContact] = useState(null);
  const [beltWearPresent, setBeltWearPresent] = useState(null);
  const [beltType, setBeltType] = useState(null);
  const [submitButton, setSubmitButton] = useState(null);
  const [pageLoader, setPageLoader] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const onChangeDryWet = (e) => {
    console.log("radio Dry/Wet checked", e.target.value);
    setWorkingCondition(e.target.value);
  };
  const onChangeLaggingContact = (e) => {
    console.log("radio Carry checked", e.target.value);
    setLaggingContact(e.target.value);
  };

  const onChangeBelt = (e) => {
    console.log("radio belt checked", e.target.value);
    setBeltWearPresent(e.target.value);
  };
  const onChangeBeltType = (e) => {
    console.log("radio belt type checked", e.target.value);
    setBeltType(e.target.value);
  };

  const options = [
    {
      value: "Elastotec Diamond Rubber",
      label: "Elastotec Diamond Rubber",
      key: "Elastotec Diamond Rubber",
      children: [
        {
          value: "Elastotec Diamond Rubber, 25 mm, 65 duro",
          label: "Elastotec Diamond Rubber, 25 mm, 65 duro",
          key: "Elastotec Diamond Rubber, 25 mm, 65 duro",
        },
        {
          value: "Elastotec Diamond Rubber, 30 mm, 50 duro",
          label: "Elastotec Diamond Rubber, 30 mm, 50 duro",
          key: "Elastotec Diamond Rubber, 30 mm, 50 duro",
        },
        {
          value: "Elastotec Diamond Rubber, 25 mm, 50 duro",
          label: "Elastotec Diamond Rubber, 25 mm, 50 duro",
          key: "Elastotec Diamond Rubber, 25 mm, 50 duro",
        },
        {
          value: "Elastotec Diamond Rubber, 12 mm, 65 duro",
          label: "Elastotec Diamond Rubber, 12 mm, 65 duro",
          key: "Elastotec Diamond Rubber, 12 mm, 65 duro",
        },
      ],
    },
    {
      value: "Hand Cut Diamond Rubber 300x105x5, 15 mm, 65 duro",
      label: "Hand Cut Diamond Rubber 300x105x5, 15 mm, 65 duro",
      key: "Hand Cut Diamond Rubber 300x105x5, 15 mm, 65 duro",
    },
    {
      value: "HC Diamond Rubber 90x50x10, 25 mm, 65 duro",
      label: "HC Diamond Rubber 90x50x10, 25 mm, 65 duro",
      key: "HC Diamond Rubber 90x50x10, 25 mm, 65 duro",
    },

    {
      value: "Herringbone Rubber 150x8, 25 mm, 60 duro",
      label: "Herringbone Rubber 150x8, 25 mm, 60 duro",
      key: "Herringbone Rubber 150x8, 25 mm, 60 duro",
    },
    {
      value: "Elastotec HTB Rubber, 25 mm, 65 duro",
      label: "Elastotec HTB Rubber, 25 mm, 65 duro",
      key: "Elastotec HTB Rubber, 25 mm, 65 duro",
    },
    {
      value: "Elastotec Extreme Rubber",
      label: "Elastotec Extreme Rubber",
      key: "Elastotec Extreme Rubber",
      children: [
        {
          value: "Elastotec Extreme Rubber, 16 mm, 65 duro",
          label: "Elastotec Extreme Rubber, 16 mm, 65 duro",
          key: "Elastotec Extreme Rubber, 16 mm, 65 duro",
        },
        {
          value: "Elastotec Extreme Rubber, 25 mm, 65 duro",
          label: "Elastotec Extreme Rubber, 25 mm, 65 duro",
          key: "Elastotec Extreme Rubber, 25 mm, 65 duro",
        },
      ],
    },

    {
      value: "Elastotec 15% Ceramic Diamond",
      label: "Elastotec 15% Ceramic Diamond",
      key: "Elastotec 15% Ceramic Diamond",
      children: [
        {
          value: "Elastotec 15% Ceramic Diamond, 25 mm, 65 duro",
          label: "Elastotec 15% Ceramic Diamond, 25 mm, 65 duro",
          key: "Elastotec 15% Ceramic Diamond, 25 mm, 65 duro",
        },
        {
          value: "Elastotec 15% Ceramic Diamond, 12 mm, 65 duro",
          label: "Elastotec 15% Ceramic Diamond, 12 mm, 65 duro",
          key: "Elastotec 15% Ceramic Diamond, 12 mm, 65 duro",
        },
      ],
    },
    {
      value: "Elastotec 20% Ceramic Dimpled",
      label: "Elastotec 20% Ceramic Dimpled",
      key: "Elastotec 20% Ceramic Dimpled",
      children: [
        {
          value: "Elastotec 20% Ceramic Dimpled, 25 mm, 65 duro",
          label: "Elastotec 20% Ceramic Dimpled, 25 mm, 65 duro",
          key: "Elastotec 20% Ceramic Dimpled, 25 mm, 65 duro",
        },
        {
          value: "Elastotec 20% Ceramic Dimpled, 12 mm, 65 duro",
          label: "Elastotec 20% Ceramic Dimpled, 12 mm, 65 duro",
          key: "Elastotec 20% Ceramic Dimpled, 12 mm, 65 duro",
        },
      ],
    },
    {
      value: "Elastotec 38% Ceramic Smooth, 12 mm, 65 duro",
      label: "Elastotec 38% Ceramic Smooth, 12 mm, 65 duro",
      key: "Elastotec 38% Ceramic Smooth, 12 mm, 65 duro",
    },
    {
      value: "Elastotec 38% Ceramic Dimpled",
      label: "Elastotec 38% Ceramic Dimpled",
      key: "Elastotec 38% Ceramic Dimpled",
      children: [
        {
          value: "Elastotec 38% Ceramic Dimpled, 12 mm, 65 duro",
          label: "Elastotec 38% Ceramic Dimpled, 12 mm, 65 duro",
          key: "Elastotec 38% Ceramic Dimpled, 12 mm, 65 duro",
        },
        {
          value: "Elastotec 38% Ceramic Dimpled, 25 mm, 65 duro",
          label: "Elastotec 38% Ceramic Dimpled, 25 mm, 65 duro",
          key: "Elastotec 38% Ceramic Dimpled, 25 mm, 65 duro",
        },
        {
          value: "Elastotec 38% Ceramic Dimpled, 25 mm, 60 duro",
          label: "Elastotec 38% Ceramic Dimpled, 25 mm, 60 duro",
          key: "Elastotec 38% Ceramic Dimpled, 25 mm, 60 duro",
        },
      ],
    },
    {
      value: "Elastotec 80% Ceramic Smooth, 12 mm, 65 duro",
      label: "Elastotec 80% Ceramic Smooth, 12 mm, 65 duro",
      key: "Elastotec 80% Ceramic Smooth, 12 mm, 65 duro",
    },
    {
      value: "Elastotec 80% Ceramic Dimpled",
      label: "Elastotec 80% Ceramic Dimpled",
      key: "Elastotec 80% Ceramic Dimpled",
      children: [
        {
          value: "Elastotec 80% Ceramic Dimpled, 12 mm, 65 duro",
          label: "Elastotec 80% Ceramic Dimpled, 12 mm, 65 duro",
          key: "Elastotec 80% Ceramic Dimpled, 12 mm, 65 duro",
        },
        {
          value: "Elastotec 80% Ceramic Dimpled, 25 mm, 65 duro",
          label: "Elastotec 80% Ceramic Dimpled, 25 mm, 65 duro",
          key: "Elastotec 80% Ceramic Dimpled, 25 mm, 65 duro",
        },
      ],
    },
    {
      value: "Elastotec 80% Ceramic Extreme, 25 mm, 65 duro",
      label: "Elastotec 80% Ceramic Extreme, 25 mm, 65 duro",
      key: "Elastotec 80% Ceramic Extreme, 25 mm, 65 duro",
    },
    {
      value: "Direct Bond Dimpled, 6 mm, 0 duro",
      label: "Direct Bond Dimpled, 6 mm, 0 duro",
      key: "Direct Bond Dimpled, 6 mm, 0 duro",
    },
    {
      value: "Direct Bond Smooth, 6 mm, 0 duro",
      label: "Direct Bond Smooth, 6 mm, 0 duro",
      key: "Direct Bond Smooth, 6 mm, 0 duro",
    },
  ];

  const splitString = (item) => {
    const components = item.split(", ");
    if (components.length >= 3) {
      const Product = components[0];
      const Thk = components[1].split(" ")[0];
      const Duro = components[2].split(" ")[0];
      return { Product, Thk, Duro };
    } else {
      return null;
    }
  };

  const onFinish = async (values) => {
    console.log("simulate values", values);

    // Assuming values.products is an array of selected values
    const selectedProducts = values.products;

    console.log(selectedProducts, "selectedProducts");

    if (
      (selectedProducts.length === 1 && selectedProducts[0] == null) ||
      !selectedProducts.length
    ) {
      return Notification.error("Please select a products");
    }

    // Create a new array to hold the values
    const newValuesArray = [];

    for (let main of options) {
      if (selectedProducts.includes(main["value"])) {
        if (main["children"]) {
          for (let children of main["children"]) {
            newValuesArray.push(children["value"]);
          }
        } else {
          newValuesArray.push(main["value"]);
        }
      } else {
        if (main["children"]) {
          for (let children of main["children"]) {
            if (selectedProducts.includes(children["value"])) {
              newValuesArray.push(children["value"]);
            }
          }
        }
      }
    }

    let obj = {
      Speed: +values.beltSpeed,
      T1: +values.tensionInT1,
      T2: +values.tensionInT2,
      OpHours: +values.operatingHours,
      RimDiam: +values.pulleyShellDiameter,
      Wrap: +values.wrapAngle,
      Gen: {
        Client: "ACT",
        Project: projectName,
        Engineer: "Tarun",
        Description: "Primary Drive",
      },
      Belt: {
        Width: +values.width,
        Rating: +values.rating,
        Type: +values.type,
        ContactCvrThk: +values.contactCoverThickness,
        CvrWearDepth:
          values.beltCoverWearDepth === undefined
            ? 0
            : +values.beltCoverWearDepth,
        CvrWearWidth:
          values.beltCoverWearWidth === undefined
            ? 0
            : +values.beltCoverWearWidth,
        Duro: +values.durometer,
      },
      Lagwear: {
        WearDepth:
          values.laggingWearDepth === undefined ? 0 : +values.laggingWearDepth,
        WearWidth:
          values.laggingWearWidth === undefined ? 0 : +values.laggingWearWidth,
      },
    };

    const updatedPayload = [];
    const sim = [];

    for (let item of newValuesArray) {
      item = splitString(item);

      const objData = ProductsDB.find((product) => {
        if (
          product.Product === item.Product &&
          product.Thk === +item.Thk &&
          product.Duro === +item.Duro
        ) {
          return product;
        }
      });

      const finalPayload = {
        LagEnv: objData,
        Lagcoef:
          values.workingCondition === "Dry Clean"
            ? FrictCoef["DryClean"][objData["Material"]]
            : FrictCoef["WetDirty"][objData["Material"]],
        LagcoefDry: FrictCoef["DryClean"][objData["Material"]],
        LagcoefWet: FrictCoef["WetDirty"][objData["Material"]],
        SN: SN,
        ...obj,
      };

      if (submitButton === "save") {
        updatedPayload.push(finalPayload);
      } else if (submitButton === "simulate") {
        setSimulateOutput("");
        setPageLoader(true);
        try {
          const response = await axios.post(
            `https://lag-sel-44r3qwdg4a-an.a.run.app/sim`,
            finalPayload,
            {
              headers: {
                Auth: `Bearer ${loginToken}`,
              },
            }
          );
          if (response !== undefined) {
            sim.push(response.data);
            setPageLoader(false);
          }
        } catch (error) {
          console.log(error);
          Notification.error("Please add all the values");
          setPageLoader(false);
        }
      }
    }
    // set simulate output Data
    setSimulateOutput(sim);

    if (submitButton === "save" && updatedPayload.length) {
      setPageLoader(true);
      try {
        const response = await axios.post(
          `${baseUrl}/project/updatePulleyDetails`,
          {
            PROJECT_ID: selectedProjectId,
            CONVEYOR_ID: selectedConveyorId,
            PULLEY_ID: selectedPulleyId,
            PAYLOAD_LIST: updatedPayload,
          }
        );
        if (response !== undefined) {
          setLaggingInputData(updatedPayload);
          Notification.success(response.data);
          setPageLoader(false);
        }
      } catch (error) {
        console.log(error);
        setPageLoader(false);
      }
    }

    setCurrent(1);
  };

  useEffect(() => {
    console.log("laggingInputData has changed:", laggingInputData);

    // Define a function to calculate demand power
    const calculateDemandPower = (data) => {
      return (data.T1 - data.T2) * (data.Speed / 0.95);
    };

    // Define a function to determine the lag coefficient
    const getLagCoefficient = (data) => {
      if (
        data.Lagcoef.A === data.LagcoefWet.A &&
        data.Lagcoef.B === data.LagcoefWet.B &&
        data.Lagcoef.Lim === data.LagcoefWet.Lim &&
        data.Lagcoef.Asm === data.LagcoefWet.Asm
      ) {
        return "Wet Dirty";
      }
      return "Dry Clean";
    };

    // Define a function to calculate the Belt Safety Factor
    const calculateBeltSafetyFactor = (data) => {
      return (data.Belt?.Rating * data.Belt?.Width) / data.T1;
    };

    // Define a function to calculate Elastic Modulus
    const calculateElasticModulus = (data) => {
      return (
        (0.0981 * (56 + 7.62336 * data.Belt?.Duro)) /
        (0.137505 * (254 - 2.54 * data.Belt?.Duro))
      );
    };

    // Loop through the laggingInputData and set form values
    for (let i = 0; i < laggingInputData.length; i++) {
      const data = laggingInputData[i];

      const productName = `${data?.LagEnv?.Product}, ${data?.LagEnv?.Thk} mm, ${data?.LagEnv?.Duro} duro`;
      const lagcoef = getLagCoefficient(data);
      const BeltSafetyFactor = calculateBeltSafetyFactor(data);
      const ElasticModulus = calculateElasticModulus(data);
      const demandPower = calculateDemandPower(data);

      const formValues = {
        beltSafetyFactor: Math.round(BeltSafetyFactor * 100) / 100,
        beltSpeed: data.Speed,
        contactCoverThickness: data.Belt?.ContactCvrThk,
        demandPower: Math.round(demandPower),
        durometer: data.Belt?.Duro,
        elasticModulus: Math.round(ElasticModulus * 100) / 100,
        laggingContact: laggingContact,
        operatingHours: data.OpHours,
        poissons: 0.45,
        products: productName === ", 0 mm, 0 duro" ? [null] : [productName],
        pulleyShellDiameter: data.RimDiam,
        rating: data.Belt?.Rating,
        shearModulus:
          Math.round((ElasticModulus / (2 * (1 + 0.45))) * 100) / 100,
        tensionInT1: data.T1,
        tensionInT2: data.T2,
        type: data.Belt?.Type,
        width: data.Belt?.Width,
        workingCondition: data.Lagcoef?.Condition || lagcoef,
        wrapAngle: data.Wrap,
        beltCoverWearDepth: data.Belt?.CvrWearDepth,
        beltCoverWearWidth: data.Belt?.CvrWearWidth,
        laggingWearDepth: data.Lagwear?.WearDepth,
        laggingWearWidth: data.Lagwear?.WearWidth,
        combinedWearDepth: data.Belt?.CvrWearDepth + data.Lagwear?.WearDepth,
      };

      if (i === 0) {
        setBeltType(data.Belt?.Type);
        form.setFieldsValue(formValues);
      }
    }
  }, [laggingInputData, form]);

  // useEffect(() => {
  //   console.log("laggingInputData has changed:", laggingInputData);
  //   let prod = [];
  //   let demandPower = 0;
  //   let lagcoef = "Dry Clean";
  //   let BeltSafetyFactor = 0;
  //   let ElasticModulus = 0;
  //   let Poissons = 0;
  //   let ShearModulus = 0;

  //   for (let i = 0; i < laggingInputData.length; i++) {
  //     let productName = `${laggingInputData[i]?.LagEnv?.Product}, ${laggingInputData[i]?.LagEnv?.Thk} mm, ${laggingInputData[i]?.LagEnv?.Duro} duro`;
  //     if (productName === ", 0 mm, 0 duro") {
  //       prod.push(null);
  //     } else {
  //       prod.push(productName);
  //     }
  //     if (i === 0) {
  //       setBeltType(laggingInputData[i].Belt?.Type);

  //       demandPower =
  //         (laggingInputData[i]?.T1 - laggingInputData[i]?.T2) *
  //         (laggingInputData[i]?.Speed / 0.95);
  //       if (
  //         laggingInputData[i].Lagcoef.A === laggingInputData[i].LagcoefWet.A &&
  //         laggingInputData[i].Lagcoef.B === laggingInputData[i].LagcoefWet.B &&
  //         laggingInputData[i].Lagcoef.Lim ===
  //           laggingInputData[i].LagcoefWet.Lim &&
  //         laggingInputData[i].Lagcoef.Asm === laggingInputData[i].LagcoefWet.Asm
  //       ) {
  //         lagcoef = "Wet Dirty";
  //       }

  //       BeltSafetyFactor =
  //         (laggingInputData[i].Belt?.Rating * laggingInputData[i].Belt?.Width) /
  //         laggingInputData[i]?.T1;

  //       ElasticModulus =
  //         (0.0981 * (56 + 7.62336 * laggingInputData[i].Belt?.Duro)) /
  //         (0.137505 * (254 - 2.54 * laggingInputData[i].Belt?.Duro));
  //       Poissons = 0.45;
  //       ShearModulus = ElasticModulus / (2 * (1 + Poissons));

  //       const formValues = {
  //         beltSafetyFactor: Math.round(BeltSafetyFactor * 100) / 100,
  //         beltSpeed: laggingInputData[i].Speed,
  //         contactCoverThickness: laggingInputData[i].Belt?.ContactCvrThk,
  //         demandPower: Math.round(demandPower),
  //         durometer: laggingInputData[i].Belt?.Duro,
  //         elasticModulus: Math.round(ElasticModulus * 100) / 100,
  //         laggingContact: null,
  //         operatingHours: laggingInputData[i].OpHours,
  //         poissons: Poissons,
  //         products: prod, //imp product select
  //         pulleyShellDiameter: laggingInputData[i].RimDiam,
  //         rating: laggingInputData[i].Belt?.Rating,
  //         shearModulus: Math.round(ShearModulus * 100) / 100,
  //         tensionInT1: laggingInputData[i].T1,
  //         tensionInT2: laggingInputData[i].T2,
  //         type: laggingInputData[i].Belt?.Type,
  //         width: laggingInputData[i].Belt?.Width,
  //         workingCondition: laggingInputData[i].Lagcoef?.Condition || lagcoef,
  //         wrapAngle: laggingInputData[i].Wrap,
  //         beltCoverWearDepth: laggingInputData[i].Belt?.CvrWearDepth,
  //         beltCoverWearWidth: laggingInputData[i].Belt?.CvrWearWidth,
  //         laggingWearDepth: laggingInputData[i].Lagwear?.WearDepth,
  //         laggingWearWidth: laggingInputData[i].Lagwear?.WearWidth,
  //       };
  //       form.setFieldsValue(formValues);
  //     }
  //   }
  // }, [laggingInputData, form]);

  useEffect(() => {
    let BeltElasticity = 0;
    for (let i = 0; i < laggingInputData.length; i++) {
      if (i === 0) {
        if (beltType === 1) {
          BeltElasticity = 72 * 0.18 * laggingInputData[i].Belt?.Rating;
        } else {
          BeltElasticity = 72 * laggingInputData[i]?.Belt?.Rating;
        }
      }
    }
    form.setFieldsValue({
      beltElasticity: BeltElasticity,
    });
  }, [form, beltType]);

  const kilonewtonToKip = (kN) => {
    let result = kN * 0.22481;
    return result;
  };

  const kipToKilonewton = (kips) => {
    let result = kips * 4.44822;
    return result;
  };
  function msToFpm(metersPerSecond) {
    let result = metersPerSecond * 196.850394;
    return result;
  }
  function fpmToMs(feetPerMinute) {
    let result = feetPerMinute / 196.850394;
    return result;
  }

  function mmToInches(mm) {
    // 1 inch = 25.4 mm
    let result = mm / 25.4;
    return result;
  }

  function inchesToMm(inches) {
    // 1 inch = 25.4 mm
    let result = inches * 25.4;
    return result;
  }

  function nmmToPiw(nmmValue) {
    // 1 N/mm = 5.71 PIW
    const piwValue = nmmValue * 0.5716;
    return piwValue;
  }
  function piwToNmm(piwValue) {
    // 1 PIW = 0.175 N/mm
    const nmmValue = piwValue * 0.175;
    return nmmValue;
  }

  const [value, setValue] = useState("Metric");

  const unitConversionFunctions = {
    Imperial: {
      tensionInT1: kilonewtonToKip,
      tensionInT2: kilonewtonToKip,
      beltSpeed: msToFpm,
      pulleyShellDiameter: mmToInches,
      width: mmToInches,
      contactCoverThickness: mmToInches,
      beltCoverWearDepth: mmToInches,
      laggingWearDepth: mmToInches,
      beltCoverWearWidth: mmToInches,
      laggingWearWidth: mmToInches,
      rating: nmmToPiw,
    },
    Metric: {
      tensionInT1: kipToKilonewton,
      tensionInT2: kipToKilonewton,
      beltSpeed: fpmToMs,
      pulleyShellDiameter: inchesToMm,
      width: inchesToMm,
      contactCoverThickness: inchesToMm,
      beltCoverWearDepth: inchesToMm,
      laggingWearDepth: inchesToMm,
      beltCoverWearWidth: inchesToMm,
      laggingWearWidth: inchesToMm,
      rating: piwToNmm,
    },
  };

  const onChange = (e) => {
    const selectedUnit = e.target.value;
    const conversionFunctions = unitConversionFunctions[selectedUnit];

    const updatedFields = {};
    Object.keys(conversionFunctions).forEach((fieldName) => {
      const conversionFunction = conversionFunctions[fieldName];
      const fieldValue = form.getFieldValue(fieldName);
      // updatedFields[fieldName] = conversionFunction(fieldValue);
      if (fieldValue === "") {
        updatedFields[fieldName] = ""; // Keep it empty if it's already empty
      } else if (!isNaN(fieldValue)) {
        updatedFields[fieldName] = conversionFunction(fieldValue);
      } else {
        // Handle invalid input by keeping the field empty
        updatedFields[fieldName] = 0;
      }
    });
    form.setFieldsValue(updatedFields);
    setValue(selectedUnit);
  };

  const [selectedValues, setSelectedValues] = useState([]);

  const handleChange = (newSelectedValues) => {
    if (newSelectedValues.length <= 10) {
      setSelectedValues(newSelectedValues);
    } else {
      Notification.error("You conn't select more then 10 values");
    }
  };

  return (
    <div>
      <Card
        style={{
          boxShadow: "0px 0px 80px #00000029",
          paddingTop: "0px",
        }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <div
          style={{
            overflowY: isHovered ? "auto" : "hidden",
            overflowX: isHovered ? "hidden" : "hidden",
            height: "74.5vh",
          }}
        >
          <>
            <Radio.Group onChange={onChange} value={value}>
              <Radio value={"Metric"}>Metric</Radio>
              <Radio value={"Imperial"}>Imperial</Radio>
            </Radio.Group>
          </>
          <Form onFinish={onFinish} form={form}>
            <p style={{ fontWeight: "bold" }}>Lagging Operating Conditions</p>
            <Row gutter={[16, 16]}>
              <Col span={10}>
                <div style={{ fontSize: "14px", color: "#6F6F6F" }}>
                  Working Condition
                </div>
                <Form.Item name="workingCondition">
                  <Radio.Group
                    onChange={onChangeDryWet}
                    value={workingCondition}
                  >
                    <Radio value={"Dry Clean"}>Dry</Radio>
                    <Radio value={"Wet Dirty"}>Wet / Dirty</Radio>
                  </Radio.Group>
                </Form.Item>
              </Col>
              <Col span={14}>
                <div style={{ fontSize: "14px", color: "#6F6F6F" }}>
                  {/* Carry Side : Dirty Belt - Pulley Contact */}
                  Lagging Contact
                </div>
                <Form.Item name={"laggingContact"}>
                  <Radio.Group
                    onChange={onChangeLaggingContact}
                    value={laggingContact}
                  >
                    <Radio value={"BletTopCover"}>
                      {/* Yes */}
                      Belt Top Cover
                    </Radio>
                    <Radio value={"BeltBottomCover"}>
                      {/* No */}
                      Belt Bottom Cover
                    </Radio>
                  </Radio.Group>
                </Form.Item>
              </Col>
            </Row>
            <Row>
              {laggingContact === "BletTopCover" ? (
                <>
                  <div style={{ fontSize: "14px", color: "#6F6F6F" }}>
                    Belt Wear Present
                  </div>
                  <Col span={24}>
                    <Form.Item name="beltWearPresent">
                      <Radio.Group
                        onChange={onChangeBelt}
                        value={beltWearPresent}
                      >
                        <Radio value={"No"}>No</Radio>
                        <Radio value={"Yes"}>Yes</Radio>
                      </Radio.Group>
                    </Form.Item>
                  </Col>
                </>
              ) : null}
            </Row>

            <p style={{ fontWeight: "bold" }}>Conveyor Details</p>

            <Row gutter={[16, 16]}>
              <Col span={12}>
                <label>Tension In (T1)</label>
                <Form.Item
                  name="tensionInT1"
                  rules={[
                    // {
                    //   required: true,
                    //   message: "Please input your Tension In (T1)!",
                    // },
                    {
                      validator: (rule, value) => {
                        if (!value) {
                          return Promise.resolve(); // Allow empty input
                        }
                        if (!/^\d+(\.\d+)?$/.test(value)) {
                          return Promise.reject("Please enter a valid number.");
                        }
                        return Promise.resolve();
                      },
                    },
                  ]}
                >
                  <Input
                    type="text"
                    placeholder="Enter the value"
                    addonAfter={value === "Metric" ? "kN" : "kips"}
                  />
                </Form.Item>
              </Col>
              <Col span={12}>
                <label>Tension In (T2)</label>
                <Form.Item
                  name="tensionInT2"
                  rules={[
                    // {
                    //   required: true,
                    //   message: "Please input your Tension In (T2)!",
                    // },
                    {
                      validator: (rule, value) => {
                        if (!value) {
                          return Promise.resolve(); // Allow empty input
                        }
                        if (!/^\d+(\.\d+)?$/.test(value)) {
                          return Promise.reject("Please enter a valid number.");
                        }
                        return Promise.resolve();
                      },
                    },
                  ]}
                >
                  <Input
                    type="text"
                    placeholder="Enter the value"
                    addonAfter={value === "Metric" ? "kN" : "kips"}
                  />
                </Form.Item>
              </Col>
              <Col span={12}>
                <label>Belt Speed</label>
                <Form.Item
                  name="beltSpeed"
                  rules={[
                    // {
                    //   required: true,
                    //   message: "Please input your Belt Speed!",
                    // },
                    {
                      validator: (rule, value) => {
                        if (!value) {
                          return Promise.resolve(); // Allow empty input
                        }
                        if (!/^\d+(\.\d+)?$/.test(value)) {
                          return Promise.reject("Please enter a valid number.");
                        }
                        return Promise.resolve();
                      },
                    },
                  ]}
                >
                  <Input
                    type="text"
                    placeholder="Enter the value"
                    addonAfter={value === "Metric" ? "m/s" : "fpm"}
                  />
                </Form.Item>
              </Col>
              <Col span={12}>
                <label>
                  {/* Operating Hours */}
                  Annual Operating Hours
                </label>
                <Form.Item
                  name="operatingHours"
                  rules={[
                    // {
                    //   required: true,
                    //   message: "Please input your Operating Hours!",
                    // },
                    {
                      validator: (rule, value) => {
                        if (!value) {
                          return Promise.resolve(); // Allow empty input
                        }
                        if (!/^\d+(\.\d+)?$/.test(value)) {
                          return Promise.reject("Please enter a valid number.");
                        }
                        return Promise.resolve();
                      },
                    },
                  ]}
                >
                  <Input
                    type="text"
                    placeholder="Enter the value"
                    addonAfter={"hrs"}
                  />
                </Form.Item>
              </Col>
              <Col span={24}>
                <label>Demand Power</label>
                <Form.Item
                  name="demandPower"
                  rules={
                    [
                      // {
                      //   required: true,
                      //   message: "Please input your Demand Power!",
                      // },
                      // {
                      //   validator: (rule, value) => {
                      //     if (!value) {
                      //       return Promise.resolve(); // Allow empty input
                      //     }
                      //     if (!/^\d+(\.\d+)?$/.test(value)) {
                      //       return Promise.reject("Please enter a valid number.");
                      //     }
                      //     return Promise.resolve();
                      //   },
                      // },
                    ]
                  }
                >
                  <Input
                    disabled
                    type="text"
                    placeholder="Demand Power"
                    addonAfter={value === "Metric" ? "kW" : "hp"}
                  />
                </Form.Item>
              </Col>
            </Row>

            <p style={{ fontWeight: "bold" }}>Pulley Details</p>

            <Row gutter={[16, 16]}>
              <Col span={12}>
                <label>Pulley Shell Diameter</label>
                <Form.Item
                  name="pulleyShellDiameter"
                  rules={[
                    // {
                    //   required: true,
                    //   message: "Please input your Pulley Shell Diameter!",
                    // },
                    {
                      validator: (rule, value) => {
                        if (!value) {
                          return Promise.resolve(); // Allow empty input
                        }
                        if (!/^\d+(\.\d+)?$/.test(value)) {
                          return Promise.reject("Please enter a valid number.");
                        }
                        return Promise.resolve();
                      },
                    },
                  ]}
                >
                  <Input
                    type="text"
                    placeholder="Enter the value"
                    addonAfter={value === "Metric" ? "mm" : "in"}
                  />
                </Form.Item>
              </Col>
              <Col span={12}>
                <label>Wrap Angle</label>
                <Form.Item
                  name="wrapAngle"
                  rules={[
                    // {
                    //   required: true,
                    //   message: "Please input your Pulley Details!",
                    // },
                    {
                      validator: (rule, value) => {
                        if (!value) {
                          return Promise.resolve(); // Allow empty input
                        }
                        if (!/^\d+(\.\d+)?$/.test(value)) {
                          return Promise.reject("Please enter a valid number.");
                        }
                        return Promise.resolve();
                      },
                    },
                  ]}
                >
                  <Input
                    type="text"
                    placeholder="Enter the value"
                    addonAfter={"deg."}
                  />
                </Form.Item>
              </Col>
            </Row>

            <p style={{ fontWeight: "bold" }}>Belt Details</p>
            <Form.Item name="type" label="Type">
              <Radio.Group onChange={onChangeBeltType} value={beltType}>
                <Radio value={0}>Steel Cord</Radio>
                <Radio value={1}>Fabric</Radio>
              </Radio.Group>
            </Form.Item>

            <Row gutter={[16, 16]}>
              <Col span={12}>
                <label>Rating</label>
                <Form.Item
                  name="rating"
                  rules={[
                    // {
                    //   required: true,
                    //   message: "Please input your Rating!",
                    // },
                    {
                      validator: (rule, value) => {
                        if (!value) {
                          return Promise.resolve(); // Allow empty input
                        }
                        if (!/^\d+(\.\d+)?$/.test(value)) {
                          return Promise.reject("Please enter a valid number.");
                        }
                        return Promise.resolve();
                      },
                    },
                  ]}
                >
                  <Input
                    type="text"
                    placeholder="Enter the value"
                    addonAfter={value === "Metric" ? "N/mm" : "piw"}
                  />
                </Form.Item>
              </Col>
              <Col span={12}>
                <label>Width</label>

                <Form.Item
                  name="width"
                  rules={[
                    // {
                    //   required: true,
                    //   message: "Please input your Width!",
                    // },
                    {
                      validator: (rule, value) => {
                        if (!value) {
                          return Promise.resolve(); // Allow empty input
                        }
                        if (!/^\d+(\.\d+)?$/.test(value)) {
                          return Promise.reject("Please enter a valid number.");
                        }
                        return Promise.resolve();
                      },
                    },
                  ]}
                >
                  <Input
                    type="text"
                    placeholder="Enter the value"
                    addonAfter={value === "Metric" ? "mm" : "in"}
                  />
                </Form.Item>
              </Col>

              <Col span={12}>
                <label>Belt Safety Factor</label>
                <Form.Item
                  name="beltSafetyFactor"
                  rules={
                    [
                      // {
                      //   validator: (rule, value) => {
                      //     if (!value) {
                      //       return Promise.resolve(); // Allow empty input
                      //     }
                      //     if (!/^\d+(\.\d+)?$/.test(value)) {
                      //       return Promise.reject("Please enter a valid number.");
                      //     }
                      //     return Promise.resolve();
                      //   },
                      // },
                    ]
                  }
                >
                  <Input
                    disabled
                    type="text"
                    placeholder="Belt Safety Factor"
                    addonAfter={":1"}
                  />
                </Form.Item>
              </Col>
              <Col span={12}>
                <label>Belt Elasticity</label>
                <Form.Item
                  name="beltElasticity"
                  rules={
                    [
                      // {
                      //   validator: (rule, value) => {
                      //     if (!value) {
                      //       return Promise.resolve(); // Allow empty input
                      //     }
                      //     if (!/^\d+(\.\d+)?$/.test(value)) {
                      //       return Promise.reject("Please enter a valid number.");
                      //     }
                      //     return Promise.resolve();
                      //   },
                      // },
                    ]
                  }
                >
                  <Input
                    disabled
                    type="text"
                    placeholder="Belt Elasticity"
                    addonAfter={value === "Metric" ? "N/mm" : "piw"}
                  />
                </Form.Item>
              </Col>

              <Col span={12}>
                <label>Contact Cover Thickness</label>

                <Form.Item
                  name="contactCoverThickness"
                  rules={[
                    // {
                    //   required: true,
                    //   message: "Please input your Contact Cover Thickness!",
                    // },
                    {
                      validator: (rule, value) => {
                        if (!value) {
                          return Promise.resolve(); // Allow empty input
                        }
                        if (!/^\d+(\.\d+)?$/.test(value)) {
                          return Promise.reject("Please enter a valid number.");
                        }
                        return Promise.resolve();
                      },
                    },
                  ]}
                >
                  <Input
                    type="text"
                    placeholder="Enter the value"
                    addonAfter={value === "Metric" ? "mm" : "in"}
                  />
                </Form.Item>
              </Col>
              <Col span={12}>
                <label>
                  {/* Durometer */}
                  Contact Cover Durometer
                </label>
                <Form.Item
                  name="durometer"
                  rules={[
                    // {
                    //   required: true,
                    //   message: "Please input your Durometer!",
                    // },
                    {
                      validator: (rule, value) => {
                        if (!value) {
                          return Promise.resolve(); // Allow empty input
                        }
                        if (!/^\d+(\.\d+)?$/.test(value)) {
                          return Promise.reject("Please enter a valid number.");
                        }
                        return Promise.resolve();
                      },
                    },
                  ]}
                >
                  <Input
                    type="text"
                    placeholder="Enter the value"
                    addonAfter={value === "Metric" ? "shore A" : "Duro"}
                  />
                </Form.Item>
              </Col>
              <Col span={12}>
                <label>Elastic Modulus</label>
                <Form.Item
                  name="elasticModulus"
                  rules={
                    [
                      // {
                      //   validator: (rule, value) => {
                      //     if (!value) {
                      //       return Promise.resolve(); // Allow empty input
                      //     }
                      //     if (!/^\d+(\.\d+)?$/.test(value)) {
                      //       return Promise.reject("Please enter a valid number.");
                      //     }
                      //     return Promise.resolve();
                      //   },
                      // },
                    ]
                  }
                >
                  <Input
                    disabled
                    type="text"
                    placeholder="Elastic Modulus"
                    addonAfter={value === "Metric" ? "Mpa" : "ksi"}
                  />
                </Form.Item>
              </Col>
              <Col span={12}>
                <label>Poissons</label>
                <Form.Item
                  name="poissons"
                  rules={
                    [
                      // {
                      //   validator: (rule, value) => {
                      //     if (!value) {
                      //       return Promise.resolve(); // Allow empty input
                      //     }
                      //     if (!/^\d+(\.\d+)?$/.test(value)) {
                      //       return Promise.reject("Please enter a valid number.");
                      //     }
                      //     return Promise.resolve();
                      //   },
                      // },
                    ]
                  }
                >
                  <Input
                    disabled
                    type="text"
                    placeholder="Poissons"
                    addonAfter={" "}
                  />
                </Form.Item>
              </Col>
              <Col span={24}>
                <label>Shear Modulus</label>
                <Form.Item
                  name="shearModulus"
                  rules={
                    [
                      // {
                      //   validator: (rule, value) => {
                      //     if (!value) {
                      //       return Promise.resolve(); // Allow empty input
                      //     }
                      //     if (!/^\d+(\.\d+)?$/.test(value)) {
                      //       return Promise.reject("Please enter a valid number.");
                      //     }
                      //     return Promise.resolve();
                      //   },
                      // },
                    ]
                  }
                >
                  <Input
                    disabled
                    type="text"
                    placeholder="Shear Modulus"
                    addonAfter={value === "Metric" ? "Mpa" : "ksi"}
                  />
                </Form.Item>
              </Col>
            </Row>

            <p style={{ fontWeight: "bold" }}>Lagging Definition</p>

            <Row gutter={[16, 16]}>
              <Col span={24}>
                <label>Products</label>
                <Form.Item
                  name="products"
                  rules={
                    [
                      // {
                      //   required: true,
                      //   message: "Please input your Products!",
                      // },
                    ]
                  }
                >
                  <TreeSelect
                    treeData={options}
                    style={{ width: "100%" }}
                    placeholder="Select options"
                    value={selectedValues}
                    onChange={handleChange}
                    treeCheckable
                    showCheckedStrategy={SHOW_PARENT}
                    // treeCheckStrictly={true}
                    placement="topRight"
                    className="custom-checkbox"
                  />
                </Form.Item>
              </Col>
            </Row>
            {beltWearPresent === "Yes" ? (
              <>
                <p style={{ fontWeight: "bold" }}>Wear Details</p>

                <Row gutter={[16, 16]}>
                  <Col span={12}>
                    <label>Belt Cover Wear Depth</label>
                    <Form.Item
                      name="beltCoverWearDepth"
                      rules={[
                        // {
                        //   required: true,
                        //   message: "Please input your Belt Cover Wear Depth!",
                        // },
                        {
                          validator: (rule, value) => {
                            if (!value) {
                              return Promise.resolve(); // Allow empty input
                            }
                            if (!/^\d+(\.\d+)?$/.test(value)) {
                              return Promise.reject(
                                "Please enter a valid number."
                              );
                            }
                            return Promise.resolve();
                          },
                        },
                      ]}
                    >
                      <Input
                        type="text"
                        placeholder="Enter the value"
                        addonAfter={value === "Metric" ? "mm" : "in"}
                      />
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <label>Lagging Wear Depth</label>
                    <Form.Item
                      name="laggingWearDepth"
                      rules={[
                        // {
                        //   required: true,
                        //   message: "Please input your Lagging Wear Depth!",
                        // },
                        {
                          validator: (rule, value) => {
                            if (!value) {
                              return Promise.resolve(); // Allow empty input
                            }
                            if (!/^\d+(\.\d+)?$/.test(value)) {
                              return Promise.reject(
                                "Please enter a valid number."
                              );
                            }
                            return Promise.resolve();
                          },
                        },
                      ]}
                    >
                      <Input
                        type="text"
                        placeholder="Enter the value"
                        addonAfter={value === "Metric" ? "mm" : "in"}
                      />
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <label>Belt Cover Wear Width</label>
                    <Form.Item
                      name="beltCoverWearWidth"
                      rules={[
                        // {
                        //   required: true,
                        //   message: "Please input your Belt Cover Wear Width!",
                        // },
                        {
                          validator: (rule, value) => {
                            if (!value) {
                              return Promise.resolve(); // Allow empty input
                            }
                            if (!/^\d+(\.\d+)?$/.test(value)) {
                              return Promise.reject(
                                "Please enter a valid number."
                              );
                            }
                            return Promise.resolve();
                          },
                        },
                      ]}
                    >
                      <Input
                        type="text"
                        placeholder="Enter the value"
                        addonAfter={value === "Metric" ? "mm" : "in"}
                      />
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <label>Lagging Wear Width</label>
                    <Form.Item
                      name="laggingWearWidth"
                      rules={[
                        // {
                        //   required: true,
                        //   message: "Please input your Lagging Wear Width!",
                        // },
                        {
                          validator: (rule, value) => {
                            if (!value) {
                              return Promise.resolve(); // Allow empty input
                            }
                            if (!/^\d+(\.\d+)?$/.test(value)) {
                              return Promise.reject(
                                "Please enter a valid number."
                              );
                            }
                            return Promise.resolve();
                          },
                        },
                      ]}
                    >
                      <Input
                        type="text"
                        placeholder="Enter the value"
                        addonAfter={value === "Metric" ? "mm" : "in"}
                      />
                    </Form.Item>
                  </Col>
                  <Col span={24}>
                    <label>Combined Wear Depth</label>
                    <Form.Item
                      name="combinedWearDepth"
                      rules={
                        [
                          // {
                          //   validator: (rule, value) => {
                          //     if (!value) {
                          //       return Promise.resolve(); // Allow empty input
                          //     }
                          //     if (!/^\d+(\.\d+)?$/.test(value)) {
                          //       return Promise.reject(
                          //         "Please enter a valid number."
                          //       );
                          //     }
                          //     return Promise.resolve();
                          //   },
                          // },
                        ]
                      }
                    >
                      <Input
                        disabled
                        type="text"
                        placeholder="Combined Wear Depth"
                        addonAfter={value === "Metric" ? "mm" : "in"}
                      />
                    </Form.Item>
                  </Col>
                </Row>
              </>
            ) : null}
            <Space style={{ display: "flex", justifyContent: "center" }}>
              <Form.Item>
                <Button
                  type="primary"
                  style={{ backgroundColor: "#070E03" }}
                  htmlType="submit"
                  onClick={() => setSubmitButton("save")}
                >
                  SAVE
                </Button>
              </Form.Item>
              <Form.Item>
                <Button
                  type="primary"
                  htmlType="submit"
                  style={{ backgroundColor: "#F52247" }}
                  onClick={() => setSubmitButton("simulate")}
                >
                  SIMULATE
                </Button>
              </Form.Item>
            </Space>
          </Form>
        </div>
      </Card>
      <>
        <Modal
          title=""
          centered
          open={open}
          onOk={() => setOpen(false)}
          onCancel={() => setOpen(false)}
          width={1300}
          footer={false}
        >
          <div style={{ paddingTop: "1rem" }}>
            <NewLagging />
          </div>
        </Modal>
      </>
      <PageLoader visible={pageLoader} />
    </div>
  );
};

export default LaggingOperating;
