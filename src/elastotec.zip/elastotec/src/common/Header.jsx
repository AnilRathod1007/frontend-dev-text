import React, { useState } from "react";
import { Avatar, Button, Space, Modal } from "antd";
import { LogoutOutlined, UserOutlined } from "@ant-design/icons";
import { useNavigate } from "react-router-dom";
import AppStore from "src/store/AppStore";
import Lagging_Select_logo from "src/assets/Lagging_Select_logo.png";
import Conveyor_dynamics_logo from "src/assets/Conveyor_dynamics_logo.png";
import path from "src/assets/path66.png";
import logoutIcon from "src/assets/logout_icon.png";
import "../common/Header.css";
const Header = () => {
  const navigate = useNavigate();
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [login, setLogin] = AppStore("login");
  const [loginToken, setLoginToken] = AppStore("token");
  const [laggingInputData, setLaggingInputData] = AppStore("lagging");
  const [selectedPulleyId, setSelectedPulleyId] = AppStore("pulleyId");
  const [selectedProjectId, setSelectedProjectId] = AppStore("projectId");
  const [selectedConveyorId, setSelectedConveyorId] = AppStore("conveyorId");

  const [projectName, setProjectName] = AppStore("projectName");

  const showModal = () => {
    setIsModalOpen(true);
  };
  const handleOk = () => {
    navigate("/");
    setLogin("");
    setLoginToken("");
    setLaggingInputData("");

    setSelectedPulleyId(null);
    setSelectedProjectId(null);
    setSelectedConveyorId(null);
    setProjectName("");
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };

  const Logout = () => {
    showModal();
    // navigate("/");
    // setLogin("");
  };
  return (
    <>
      <header className="header">
        <div className="header-left">
          <img
            src={Lagging_Select_logo}
            alt="Elastotec"
            className="main-header"
          />
          <img src={path} alt="path" className="line-img" />

          <img
            src={Conveyor_dynamics_logo}
            alt="Lagging Select"
            className="main-header1"
          />
        </div>

        <div className="header-right">
          <Space wrap size={10} style={{ marginRight: "10px" }}>
            <Avatar size="large" icon={<UserOutlined />} />
            <span style={{ fontWeight: "bold", color: "black" }}>
              Anil Rathod
            </span>
            <Button type="text" onClick={Logout}>
              <img
                src={logoutIcon}
                alt="logoutIcon"
                width="16px"
                style={{ marginTop: "5px" }}
              />
              {/* <LogoutOutlined /> */}
            </Button>
          </Space>
        </div>
      </header>
      <Modal
        title=""
        open={isModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}
        centered={true}
        footer={false}
        width={400}
      >
        <div style={{ textAlign: "center" }}>
          <div
            style={{ color: "#161616", fontSize: "1.5rem", fontWeight: "bold" }}
          >
            Logout?
          </div>
          <p style={{ color: "#6F6F6F", paddingBottom: "1rem" }}>
            Are you sure you want to logout?
          </p>

          <Space>
            <Button
              style={{
                color: "#070E03",
                borderColor: "#070E03",
                width: "5rem",
              }}
              onClick={handleCancel}
            >
              NO
            </Button>
            <Button
              type="primary"
              style={{
                backgroundColor: "#F52247",
                // width: "100%",
                width: "5rem",
              }}
              onClick={handleOk}
            >
              YES
            </Button>
          </Space>
        </div>
      </Modal>
    </>
  );
};
export default Header;
