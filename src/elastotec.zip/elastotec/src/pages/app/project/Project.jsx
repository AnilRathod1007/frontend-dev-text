import { Col, Row, Modal, Button, Form, Input, Select } from "antd";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import Notification from "src/services/Notification";
import CustomCard from "src/common/CustomCard";
import ProjectHeader from "./ProjectHeader";
import "../project/Project.css";
import CreateProject from "./CreateProject";
import CreateConveyor from "./CreateConveyor";
import CreatePulley from "./CreatePulley";
import AppStore from "src/store/AppStore";
import axios from "axios";
import PageLoader from "src/common/PageLoader";
import baseUrl from "src/common/baseUrl";
import { InitialPayload } from "src/pages/app/project/InitialPayload";

const { Option } = Select;

const Project = () => {
  const navigate = useNavigate();
  const [form] = Form.useForm();

  const [loginToken, setLoginToken] = AppStore("token");
  const [laggingInputData, setLaggingInputData] = AppStore("lagging");
  const [selectedProjectId, setSelectedProjectId] = AppStore("projectId");
  const [selectedConveyorId, setSelectedConveyorId] = AppStore("conveyorId");
  const [selectedPulleyId, setSelectedPulleyId] = AppStore("pulleyId");
  const [projectName, setProjectName] = AppStore("projectName");

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isModalConveyor, setIsModalConveyor] = useState(false);
  const [isModalPulley, setIsModalPulley] = useState(false);

  const [reload, setReload] = useState(false);
  const [pageLoader, setPageLoader] = useState(false);
  const [projectDetails, setProjectDetails] = useState([]);
  const [conveyorDetails, setConveyorDetails] = useState([]);
  const [pulleyDetails, setPulleyDetails] = useState([]);
  const [loadings, setLoadings] = useState(false);

  // const baseUrl = "https://filemng-44r3qwdg4a-uc.a.run.app";

  const onSearch = (value) => console.log(value);

  const showModal = () => {
    setIsModalOpen(true);
  };
  const handleOk = () => {
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };

  const onAnalyes = () => {
    console.log(selectedPulleyId, "1111");
    if (selectedPulleyId !== null) {
      navigate("/analyes", { state: selectedPulleyId });
    } else if (selectedPulleyId === null) {
      Notification.error("Please Add Project, Conveyor and Pulley");
    } else if (selectedConveyorId === null) {
      Notification.error("Please add conveyor and pulley");
    } else {
      Notification.error("Please add a pulley");
    }
  };
  const onClickCard = (index) => {
    // console.log("project", index);
    setSelectedProjectId(index?.PROJECT_ID);
    setProjectName(index?.PROJECT_NAME);
    setConveyorDetails(index?.CONVEYOR_DETAILS);
  };
  const onClickConveyorCard = (index) => {
    // console.log("conveyor", index);
    setSelectedConveyorId(index?.CONVEYOR_ID);
    setPulleyDetails(index?.PULLEY_DETAILS);
  };

  const onClickPulleyCard = (index) => {
    console.log("pully Card", index);

    if (index?.PAYLOAD_LIST.length) {
      setLaggingInputData(index?.PAYLOAD_LIST);
    } else {
      setLaggingInputData(InitialPayload);
    }

    setSelectedPulleyId(index.PULLEY_ID);
  };

  useEffect(() => {
    setPageLoader(true);
    axios
      .post(`${baseUrl}/project/projectDetails`, {})
      .then((response) => {
        console.log("projectDetails", response);
        if (response !== undefined) {
          setProjectDetails(response.data);
          setProjectName(response.data[0].PROJECT_NAME);
          setConveyorDetails(response.data[0].CONVEYOR_DETAILS);
          setPulleyDetails(response.data[0].CONVEYOR_DETAILS[0].PULLEY_DETAILS);
          if (selectedPulleyId) {
            setLaggingInputData(
              response.data[0].CONVEYOR_DETAILS[0].PULLEY_DETAILS[0]
                .PAYLOAD_LIST[0]
            );
          }
          if (selectedProjectId === null) {
            setSelectedProjectId(response.data[0].PROJECT_ID);
          }

          setPageLoader(false);
        }
      })
      .catch((error) => {
        console.log(error);
        setPageLoader(false);
      });
  }, [reload]);

  useEffect(() => {
    if (selectedProjectId === null) {
      setSelectedConveyorId(null);
      return;
    }
    const selectedProject = projectDetails.find(
      (project) => project.PROJECT_ID === selectedProjectId
    );

    if (!selectedProject) {
      setSelectedConveyorId(null);
      return;
    }

    setConveyorDetails(selectedProject.CONVEYOR_DETAILS);
    setSelectedProjectId(selectedProject.PROJECT_ID);

    if (selectedProject.CONVEYOR_DETAILS.length > 0) {
      setSelectedConveyorId(selectedProject.CONVEYOR_DETAILS[0].CONVEYOR_ID);
    } else {
      setSelectedConveyorId(null);
    }
  }, [selectedProjectId, projectDetails]);

  useEffect(() => {
    if (selectedConveyorId !== null) {
      const selectedConveyor = conveyorDetails.find(
        (conveyor) => conveyor.CONVEYOR_ID === selectedConveyorId
      );
      if (selectedConveyor) {
        setPulleyDetails(selectedConveyor.PULLEY_DETAILS);
        setSelectedConveyorId(selectedConveyor.CONVEYOR_ID);
        setSelectedPulleyId(
          selectedConveyor.PULLEY_DETAILS?.[0]?.PULLEY_ID || null
        );
      } else {
        setSelectedPulleyId(null);
      }
    } else {
      setSelectedPulleyId(null);
    }
  }, [selectedConveyorId, conveyorDetails]);

  useEffect(() => {
    if (selectedPulleyId !== null) {
      const selectedPulley = pulleyDetails.find(
        (pulley) => pulley.PULLEY_ID === selectedPulleyId
      );

      if (selectedPulley && selectedPulley.PAYLOAD_LIST.length) {
        setLaggingInputData(selectedPulley.PAYLOAD_LIST);
      } else {
        setLaggingInputData(InitialPayload);
      }
    }
  }, [selectedPulleyId, pulleyDetails]);

  return (
    <div style={{ padding: "1rem" }}>
      <Row gutter={[24, 24]}>
        <Col span={24}>
          <ProjectHeader onSearch={onSearch} onClick={onAnalyes} />
        </Col>
      </Row>

      <Row gutter={[16, 16]}>
        <Col
          xl={{ span: 8 }}
          lg={{ span: 8 }}
          md={{ span: 8 }}
          sm={{ span: 24 }}
          xs={{ span: 24 }}
        >
          <CustomCard
            name={"Project"}
            buttonName={"ADD NEW"}
            data={projectDetails}
            onClick={showModal}
            onClickCard={onClickCard}
            selectedDataId={selectedProjectId}
            setSelectedDataId={setSelectedProjectId}
          />
        </Col>
        {projectDetails?.length > 0 && (
          <Col
            xl={{ span: 8 }}
            lg={{ span: 8 }}
            md={{ span: 8 }}
            sm={{ span: 24 }}
            xs={{ span: 24 }}
          >
            <CustomCard
              name={"Conveyor"}
              buttonName={"ADD NEW"}
              data={conveyorDetails}
              onClick={() => setIsModalConveyor(true)}
              onClickCard={onClickConveyorCard}
              selectedDataId={selectedConveyorId}
              setSelectedDataId={setSelectedConveyorId}
            />
          </Col>
        )}
        {conveyorDetails?.length > 0 ? (
          <Col
            xl={{ span: 8 }}
            lg={{ span: 8 }}
            md={{ span: 8 }}
            sm={{ span: 24 }}
            xs={{ span: 24 }}
          >
            <CustomCard
              name={"Pulley"}
              buttonName={"ADD NEW"}
              data={pulleyDetails}
              onClick={() => setIsModalPulley(true)}
              onClickCard={onClickPulleyCard}
              selectedDataId={selectedPulleyId}
              setSelectedDataId={setSelectedPulleyId}
            />
          </Col>
        ) : null}
      </Row>
      {/* {pulleyData.length > 0 && ( */}
      <Row
        gutter={[24, 24]}
        style={{
          padding: "1rem 0px",
          display: "flex",
          justifyContent: "end",
        }}
      >
        <Col>
          <Button
            type="primary"
            style={{
              backgroundColor: "#F52247",
            }}
            // disabled={pulleyData.length > 0 ? false : true}
            onClick={onAnalyes}
          >
            ANALYSE
          </Button>
        </Col>
      </Row>
      {/* )} */}
      <>
        <Modal
          title=""
          open={isModalOpen}
          onOk={handleOk}
          onCancel={handleCancel}
          centered={true}
          footer={false}
          width={400}
        >
          {/* <CreateConveyor /> */}
          <CreateProject
            reload={reload}
            setReload={setReload}
            handleOk={handleOk}
          />
        </Modal>
        <Modal
          title=""
          open={isModalConveyor}
          onOk={() => setIsModalConveyor(false)}
          onCancel={() => setIsModalConveyor(false)}
          centered={true}
          footer={false}
          width={400}
        >
          <CreateConveyor
            selectedProjectId={selectedProjectId}
            reload={reload}
            setReload={setReload}
            setIsModalConveyor={setIsModalConveyor}
          />
        </Modal>
        <Modal
          title=""
          open={isModalPulley}
          onOk={() => setIsModalPulley(false)}
          onCancel={() => setIsModalPulley(false)}
          centered={true}
          footer={false}
          width={400}
        >
          <CreatePulley
            setIsModalPulley={setIsModalPulley}
            selectedProjectId={selectedProjectId}
            selectedConveyorId={selectedConveyorId}
            reload={reload}
            setReload={setReload}
          />
        </Modal>
      </>
      <PageLoader visible={pageLoader} />
    </div>
  );
};

export default Project;
