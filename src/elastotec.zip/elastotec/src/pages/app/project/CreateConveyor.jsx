import React, { useState } from "react";
import { Button, Form, Input, Select } from "antd";
import axios from "axios";
import baseUrl from "src/common/baseUrl";
import Notification from "src/services/Notification";

const CreateConveyor = ({
  setIsModalConveyor,
  selectedProjectId,
  reload,
  setReload,
}) => {
  const [form] = Form.useForm();
  const [loadings, setLoadings] = useState(false);

  const onFinish = (values) => {
    console.log("Success:", values);

    let conveyorObj = {
      PROJECT_ID: selectedProjectId,
      CONVEYOR_ID: values.conveyorId,
    };
    if (selectedProjectId !== null) {
      setLoadings(true);
      axios
        .post(`${baseUrl}/project/createConveyor`, conveyorObj)
        .then((response) => {
          if (response !== undefined) {
            console.log("Create conveyor", response);
            setLoadings(false);
            Notification.success(response.data);
            setReload(!reload);
            form.resetFields();
            setIsModalConveyor(false);
          }
        })
        .catch((error) => {
          Notification.error(error.response.data);
          console.log(error);
          setLoadings(false);
        });
    }
  };
  const onFinishFailed = (errorInfo) => {
    console.log("Failed:", errorInfo);
  };

  return (
    <>
      <Form
        form={form}
        name="basic"
        labelCol={{
          span: 24,
        }}
        wrapperCol={{
          span: 24,
        }}
        initialValues={{
          remember: true,
        }}
        onFinish={onFinish}
        onFinishFailed={onFinishFailed}
        autoComplete="off"
      >
        <Form.Item
          label="Conveyor Id"
          name="conveyorId"
          rules={[
            {
              required: true,
              message: "Please input your Conveyor Id!",
            },
          ]}
        >
          <Input placeholder="Enter the conveyor Id" />
        </Form.Item>

        <Form.Item
          wrapperCol={{
            offset: 7,
            span: 16,
          }}
        >
          <Button
            type="primary"
            htmlType="submit"
            style={{ backgroundColor: "red", width: "60%" }}
            loading={loadings}
          >
            Submit
          </Button>
        </Form.Item>
      </Form>
    </>
  );
};

export default CreateConveyor;
