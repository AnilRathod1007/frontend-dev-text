// import * as CryptoJS from "crypto-js";

// export const Encryptor = (data) => {
//   const key = "d7T-4gE-Gds-fv8";

//   var ciphertext = CryptoJS.AES.encrypt(JSON.stringify(data), key).toString();
//   return ciphertext;
// };

// export const Decryptor = (data) => {
//   const key = "d7T-4gE-Gds-fv8";

//   if (typeof data == "object") {
//     return data;
//   } else if (typeof data != "string") {
//     return null;
//   }
//   data = CryptoJS.AES.decrypt(data, key).toString(CryptoJS.enc.Utf8);
//   data = data.slice(1, -1);
//   return data;
// };
