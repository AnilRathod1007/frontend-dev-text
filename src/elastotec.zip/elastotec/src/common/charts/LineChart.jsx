import React, { useEffect, useState } from "react";
import Plot from "react-plotly.js";
import "../charts/Styles.css";
import { Button, Col, Row, Space } from "antd";
import Login from "src/pages/auth/login/Login";

const LineChart = ({ data, title, xLabel, yLabel, yLabel2 }) => {
  if (!data || data.length === 0) {
    return (
      <div className="chart-container">
        <div>No data available for this chart.</div>
      </div>
    );
  }
  const shapes = [];

  const layout = {
    title: title,
    xaxis: {
      title: xLabel,
    },

    yaxis: {
      title: yLabel,
      side: "left",
    },

    yaxis2: {
      title: yLabel2,
      overlaying: "y",
      side: "right",
      showgrid: false,
    },
    // shapes: shapes,
    showlegend: true,

    legend: {
      x: 0.05, // Adjust the x position as needed
      y: -0.4, // Place the legend below the chart by setting y to a value less than 0
      orientation: "h", // Set the orientation to horizontal
      // borderwidth: 1, // Set the border width (adjust as needed)
      bordercolor: "black", // Set the border color
      borderpad: 5, // Optional: Add padding around the border
      borderradius: 15, // Set the border radius (adjust as needed)
    },

    margin: { t: 60, pad: 0 },
    autosize: true,
    useResizeHandler: true,
    style: { width: "100%", height: "100%" },
  };

  const [traceVisibility, setTraceVisibility] = useState(
    Array(data.length).fill(true)
  );
  const [activeButtons, setActiveButtons] = useState([]);

  const toggleTraceVisibility = (index) => {
    const updatedVisibility = [...traceVisibility];
    updatedVisibility[index] = !updatedVisibility[index];
    setTraceVisibility(updatedVisibility);
    // Toggle the active state of the button
    const updatedButtons = [...activeButtons];
    if (updatedButtons.includes(index)) {
      updatedButtons.splice(updatedButtons.indexOf(index), 1);
    } else {
      updatedButtons.push(index);
    }
    setActiveButtons(updatedButtons);
  };

  const chartData = data.map((trace, index) => {
    // console.log(trace);
    return {
      ...trace,
      visible: traceVisibility[index] ? "true" : "legendonly",
    };
  });

  return (
    <>
      <div className="chart-container">
        <Plot
          data={data}
          layout={{ ...layout, selectdirection: "none" }}
          style={{
            width: "100%",
            height: "26rem",
          }}
          className="plot-area"
        />
      </div>
      {/* <div
        style={{
          padding: "0.3rem 0",
          border: "1px solid black",
          borderRadius: "5px",
          marginTop: "1rem",
          width: "100%",
          textAlign: "center",
        }}
      >
        <Row gutter={[10, 0]}>
          {data.map((trace, index) => {
            // console.log(trace, "color");
            if (trace?.showlegend === false) {
              return null;
            }
            const lineStyle = {
              border: `${trace?.line?.width ? "2px" : "1px"} ${
                trace?.line?.dash ? "dashed" : "solid"
              } ${trace?.line?.color}`,
              width: "1.5rem",
              marginRight: "0.8rem",
              textAlign: "center",
            };

            return (
              <Col span={8} key={index}>
                <Button
                  type="text"
                  onClick={() => toggleTraceVisibility(index)}
                  style={{
                    textAlign: "center",
                    padding: "0 10px",
                    opacity: activeButtons.includes(index) ? "0.5" : "1",
                    width: "5vw",
                    fontSize: "0.8rem",
                  }}
                >
                  <span>
                    <hr style={lineStyle} />
                  </span>
                  {`${trace?.name}`}
                </Button>
              </Col>
            );
          })}
        </Row>
      </div> */}
    </>
  );
};

export default LineChart;
