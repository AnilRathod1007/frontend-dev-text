import React, { useState } from "react";
import { Input, Button, Modal, Table, Checkbox, Popover } from "antd";
import icon_feather_image from "src/assets/Icon_feather_image.svg";
import Dimond_Rubber_Icon from "src/assets/Dimond_Rubber_Icon.png";
import Direct_Bond_Smooth from "src/assets/Direct_Bond_Smooth.png";

const NewLagging = () => {
  const [comments, setComments] = useState([]);
  const [commentInput, setCommentInput] = useState("");
  const [selectedRowKeys, setSelectedRowKeys] = useState([]);
  const [reportChecked, setReportChecked] = useState(false);
  const [showSelected, setShowSelected] = useState(false);

  const columns = [
    {
      title: "Lagging Information",
      children: [
        {
          title: "Product Type",
          dataIndex: "ProductType",
          key: "ProductType",
          width: 250,
          render: (_, record) => {
            console.log(record);
            return (
              <>
                <Popover
                  trigger="hover"
                  placement="rightBottom"
                  content={
                    <img
                      className="tableImage"
                      alt="ProductType"
                      src={record?.image}
                    />
                  }
                >
                  <div
                    style={{ display: "flex", justifyContent: "space-between" }}
                  >
                    <div>{record?.ProductType}</div>
                    <Button type="text">
                      <img src={icon_feather_image} />
                    </Button>
                  </div>
                </Popover>
              </>
            );
          },
        },
        {
          title: "Thickness",
          children: [
            {
              title: "(mm)",
              dataIndex: "Thickness",
              key: "Thickness",
              width: 80,
            },
          ],
        },
        {
          title: "Duro",
          dataIndex: "Duro",
          key: "Duro",
          width: 50,
        },
      ],
    },
    {
      title: "Local Slip Analysis",
      children: [
        {
          title: "Traction Utilised",
          width: 150,
          children: [
            {
              title: "(%)",
              dataIndex: "TractionUtilised",
              key: "TractionUtilised",
              width: 70,
            },
          ],
        },
        {
          title: "Local Silp",
          width: 150,
          children: [
            {
              title: "(%)",
              dataIndex: "LocalSilp",
              key: "LocalSilp",
              width: 80,
            },
          ],
        },
        {
          title: "WearPower",
          width: 150,
          children: [
            {
              title: "(W/mm)",
              dataIndex: "WearPower",
              key: "WearPower",
              width: 90,
            },
          ],
        },
        {
          title: "Minimum T2 Tension to Avoid Localised Slip",
          width: 150,
          children: [
            {
              title: "(KN)",
              dataIndex: "MinimumT2TensiontoAvoidLocalisedSlip",
              key: "MinimumT2TensiontoAvoidLocalisedSlip",
              width: 140,
            },
          ],
        },
        {
          title: "Max Shear Stress Developed",
          width: 150,
          children: [
            {
              title: "(kPa)",
              dataIndex: "MaxShearStressDeveloped",
              key: "MaxShearStressDeveloped",
              width: 100,
            },
          ],
        },
      ],
    },
    {
      title: "Lagging Fatigue Analysis",
      children: [
        {
          title: "Contact Face Shear Stress Utilisation",
          width: 150,
          children: [
            {
              title: "(%)",
              dataIndex: "ContactFaceShearStressUtilisation",
              key: "ContactFaceShearStressUtilisation",
              width: 100,
            },
          ],
        },
        {
          title: "Tread Root Shear Stress Utilisation",
          width: 150,
          children: [
            {
              title: "(%)",
              dataIndex: "TreadRootShearStressUtilisation",
              key: "TreadRootShearStressUtilisation",
              width: 100,
            },
          ],
        },
        {
          title: "Pulley Bond Shear Stress Utilisation",
          width: 150,
          children: [
            {
              title: "(%)",
              dataIndex: "PulleyBondShearStressUtilisation",
              key: "PulleyBondShearStressUtilisation",
              width: 100,
            },
          ],
        },
        {
          title: "Tile Bond Shear Stress Utilisation",
          width: 150,
          children: [
            {
              title: "(%)",
              dataIndex: "TileBondShearStressUtilisation",
              key: "TileBondShearStressUtilisation",
              width: 100,
            },
          ],
        },
      ],
    },
    {
      title: "Selection",
      dataIndex: "Selection",
      key: "Selection",
      width: 80,
      render: (_, record) => {
        const isSelected = selectedRowKeys.includes(record.key);

        return (
          <>
            <Checkbox
              className="custom-checkbox"
              checked={isSelected}
              onChange={() => handleRowSelect(record.key)}
            />
          </>
        );
      },
    },
  ];

  const data = [];
  for (let i = 0; i < 10; i++) {
    const isActive = i < 2 || i >= 8;
    const pType = i < 2 || i >= 8;
    const rowData = {
      key: i,
      ProductType: pType ? "Diamond Rubber" : "Direct Bond Smooth",
      Thickness: i + 1,
      Duro: i + 99,
      TractionUtilised: i * 2,
      LocalSilp: i * 3,
      WearPower: i * 4,
      MinimumT2TensiontoAvoidLocalisedSlip: i * 5,
      MaxShearStressDeveloped: i + 2,
      ContactFaceShearStressUtilisation: i * 10,
      TreadRootShearStressUtilisation: i * 100,
      PulleyBondShearStressUtilisation: i * 11,
      TileBondShearStressUtilisation: i * 101,
      status: isActive ? "Active" : "Inactive",
      image: isActive ? Dimond_Rubber_Icon : Direct_Bond_Smooth,
    };

    // Check values and add CSS class if greater than 100
    for (const key in rowData) {
      if (!isNaN(rowData[key]) && parseFloat(rowData[key]) > 100) {
        rowData[key] = <span style={{ color: "red" }}>{rowData[key]}</span>;
      }
    }

    data.push(rowData);
  }
  const getRowClassName = (record) => {
    // Define your conditions to change the background color based on the 'status' value.
    if (record.status === "Active") {
      return "active-row"; // CSS class name for active rows
    } else if (record.status === "Inactive") {
      return "inactive-row"; // CSS class name for inactive rows
    }
    // You can add more conditions for other status values if needed.
    return "";
  };
  const toggleShowSelected = () => {
    setShowSelected(!showSelected);
  };

  const tableFooter = (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
      }}
    >
      <label style={{ paddingRight: "10px" }}>Selection Comments</label>
      <Input
        placeholder="Type here…"
        value={commentInput}
        onChange={(e) => setCommentInput(e.target.value)}
      />

      <div>
        {showSelected ? (
          <Button
            type="text"
            onClick={toggleShowSelected}
            style={{ marginLeft: "10px", color: "#F52247" }}
          >
            Show More <DownOutlined />
          </Button>
        ) : (
          reportChecked && (
            <Button
              type="text"
              onClick={toggleShowSelected}
              style={{ marginLeft: "10px", color: "#F52247" }}
            >
              Hide <UpOutlined />
            </Button>
          )
        )}
      </div>
    </div>
  );

  const handleRowSelect = (key) => {
    // Check if the key is already selected
    const newSelectedRowKeys = selectedRowKeys.includes(key)
      ? selectedRowKeys.filter((k) => k !== key) // Deselect if already selected
      : [...selectedRowKeys, key]; // Select if not selected

    setSelectedRowKeys(newSelectedRowKeys);
  };

  return (
    <>
      <div
        style={{
          color: "#F52247",
          fontWeight: "500",
          textAlign: "center",
          paddingBottom: "1rem",
        }}
      >
        *As there is change in the values, the software has suggested new
        lagging options.
      </div>
      <div>
        <Table
          columns={columns}
          dataSource={
            showSelected
              ? data.filter((item) => selectedRowKeys.includes(item.key))
              : data
          }
          bordered
          size="middle"
          scroll={{
            x: "calc(700px + 50%)",
            y: 300,
          }}
          footer={() => tableFooter}
          rowClassName={getRowClassName}
          className="custom-header-style"
          pagination={false}
        />
      </div>
      <div
        style={{ display: "flex", justifyContent: "center", padding: "1rem" }}
      >
        <Button type="primary" style={{ backgroundColor: "#F52247" }}>
          GENERATE REPORT
        </Button>
      </div>
    </>
  );
};

export default NewLagging;
