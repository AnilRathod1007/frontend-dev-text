import React, { useState } from "react";
import {
  Button,
  Checkbox,
  Col,
  Input,
  Modal,
  Row,
  Space,
  Table,
  Popover,
  notification,
} from "antd";
import LineChart from "src/common/charts/LineChart";
import Notification from "src/services/Notification";
import { DownOutlined, UpOutlined } from "@ant-design/icons";
import path from "src/assets/path66.png";
import icon_feather_image from "src/assets/Icon_feather_image.svg";
import Dimond_Rubber_Icon from "src/assets/Dimond_Rubber_Icon.png";
import Direct_Bond_Smooth from "src/assets/Direct_Bond_Smooth.png";

import "../analyes/Styles.css";
import GenerateReport from "../generateReport/GenerateReport";

const StatisticalOutput = ({
  current,
  setCurrent,
  simulateOutput,
  laggingInputData,
}) => {
  const [comments, setComments] = useState([]);
  const [commentInput, setCommentInput] = useState("");
  const [selectedRowKeys, setSelectedRowKeys] = useState([]);
  const [selectedRowData, setSelectedRowData] = useState([]);
  const [reportChecked, setReportChecked] = useState(false);
  const [showSelected, setShowSelected] = useState(false);

  console.log("simulateOutput", simulateOutput);
  console.log("laggingInputData", laggingInputData);

  const handleAddComment = () => {
    if (commentInput.trim() !== "") {
      setComments([...comments, commentInput]);
      setCommentInput("");
    }
  };

  const columns = [
    {
      title: "Lagging Information",
      children: [
        {
          title: "Product Type",
          dataIndex: "ProductType",
          key: "ProductType",
          width: 250,
          render: (_, record) => {
            // console.log(record);
            return (
              <>
                <Popover
                  trigger="hover"
                  placement="rightBottom"
                  content={
                    <img
                      className="tableImage"
                      alt="ProductType"
                      src={record?.image}
                    />
                  }
                >
                  <div
                    style={{ display: "flex", justifyContent: "space-between" }}
                  >
                    <div>{record?.ProductType}</div>
                    <Button type="text">
                      <img src={icon_feather_image} />
                    </Button>
                  </div>
                </Popover>
              </>
            );
          },
        },
        {
          title: "Thickness",
          children: [
            {
              title: "(mm)",
              dataIndex: "Thickness",
              key: "Thickness",
              width: 80,
            },
          ],
        },
        {
          title: "Duro",
          dataIndex: "Duro",
          key: "Duro",
          width: 50,
        },
      ],
    },
    {
      title: "Local Slip Analysis",
      children: [
        {
          title: "Traction Utilised",
          width: 150,
          children: [
            {
              title: "(%)",
              dataIndex: "TractionUtilised",
              key: "TractionUtilised",
              width: 70,
            },
          ],
        },
        {
          title: "Local Slip",
          width: 150,
          children: [
            {
              title: "(%)",
              dataIndex: "LocalSlip",
              key: "LocalSlip",
              width: 80,
            },
          ],
        },
        {
          title: "WearPower",
          width: 150,
          children: [
            {
              title: "(W/mm)",
              dataIndex: "WearPower",
              key: "WearPower",
              width: 90,
            },
          ],
        },
        {
          title: "Minimum T2 Tension to Avoid Localised Slip",
          width: 150,
          children: [
            {
              title: "(KN)",
              dataIndex: "MinimumT2TensiontoAvoidLocalisedSlip",
              key: "MinimumT2TensiontoAvoidLocalisedSlip",
              width: 140,
            },
          ],
        },
        {
          title: "Max Shear Stress Developed",
          width: 150,
          children: [
            {
              title: "(kPa)",
              dataIndex: "MaxShearStressDeveloped",
              key: "MaxShearStressDeveloped",
              width: 100,
            },
          ],
        },
      ],
    },
    {
      title: "Lagging Fatigue Analysis",
      children: [
        {
          title: "Contact Face Shear Stress Utilisation",
          width: 150,
          children: [
            {
              title: "(%)",
              dataIndex: "ContactFaceShearStressUtilisation",
              key: "ContactFaceShearStressUtilisation",
              width: 100,
            },
          ],
        },
        {
          title: "Tread Root Shear Stress Utilisation",
          width: 150,
          children: [
            {
              title: "(%)",
              dataIndex: "TreadRootShearStressUtilisation",
              key: "TreadRootShearStressUtilisation",
              width: 100,
            },
          ],
        },
        {
          title: "Pulley Bond Shear Stress Utilisation",
          width: 150,
          children: [
            {
              title: "(%)",
              dataIndex: "PulleyBondShearStressUtilisation",
              key: "PulleyBondShearStressUtilisation",
              width: 100,
            },
          ],
        },
        {
          title: "Tile Bond Shear Stress Utilisation",
          width: 150,
          children: [
            {
              title: "(%)",
              dataIndex: "TileBondShearStressUtilisation",
              key: "TileBondShearStressUtilisation",
              width: 100,
            },
          ],
        },
      ],
    },
    {
      title: "Selection",
      dataIndex: "Selection",
      key: "Selection",
      width: 80,
      render: (_, record) => {
        const isSelected = selectedRowKeys.includes(record.key);

        return (
          <>
            <Checkbox
              className="custom-checkbox"
              checked={isSelected}
              onChange={() => handleRowSelect(record)}
            />
          </>
        );
      },
    },
  ];
  const tableOutput = [];

  function calculateNormalizedPressure(
    minContactPressure,
    maxContactPressure,
    AvgNormPress
  ) {
    console.log(AvgNormPress, "fun");
    if (
      minContactPressure < AvgNormPress[0] &&
      maxContactPressure > AvgNormPress[1]
    ) {
      return 1;
    } else if (
      minContactPressure < AvgNormPress[0] &&
      maxContactPressure < AvgNormPress[1] &&
      maxContactPressure > AvgNormPress[0]
    ) {
      let result =
        (maxContactPressure - AvgNormPress[0]) /
        (AvgNormPress[1] - AvgNormPress[0]);
      return result;
    } else if (
      minContactPressure > AvgNormPress[0] &&
      maxContactPressure > AvgNormPress[1] &&
      maxContactPressure < AvgNormPress[1]
    ) {
      let result =
        (AvgNormPress[1] - minContactPressure) /
        (AvgNormPress[1] - AvgNormPress[0]);
      return result;
    } else if (
      minContactPressure > AvgNormPress[0] &&
      maxContactPressure < AvgNormPress[1]
    ) {
      let result =
        (maxContactPressure - minContactPressure) /
        (AvgNormPress[1] - AvgNormPress[0]);
      return result;
    }

    return "no mathed";
  }

  for (let i = 0; i < simulateOutput.length; i++) {
    const isActive = i < 2 || i >= 8;
    const lag = laggingInputData[i];

    console.log(simulateOutput[i]["ShearStress"]);
    console.log(simulateOutput[i]["ContactPressure"]);
    console.log(simulateOutput[i]["AvgNormPress"]);
    console.log(simulateOutput[i]["TreadRootLim"]);

    // console.log("lag", lag);

    const diamondCeramic = lag.LagEnv.Material;
    const diamondRubber = lag.LagEnv.Material;

    ///////////////////////////////

    const minContactPressure = Math.min(
      ...simulateOutput[i]["ContactPressure"]
    );
    const maxContactPressure = Math.max(
      ...simulateOutput[i]["ContactPressure"]
    );

    console.log(minContactPressure, "yess");

    let NewUtilization = calculateNormalizedPressure(
      minContactPressure,
      maxContactPressure,
      simulateOutput[i]["AvgNormPress"]
    );
    console.log("New Utilization", NewUtilization);

    ////////////////////////////////

    let obj = {
      key: i,
      ProductType: lag?.LagEnv?.Product,
      Thickness: lag?.LagEnv?.Thk,
      Duro: lag?.LagEnv?.Duro,
      TractionUtilised: Math.round(simulateOutput[i]["AvailTractUtil"] * 100),
      LocalSlip: simulateOutput[i]["DegsLocalSlip"],
      WearPower: Math.round(simulateOutput[i]["SlipWearPwr"] * 100) / 100,
      MinimumT2TensiontoAvoidLocalisedSlip: Math.round(
        simulateOutput[i]["T2AvoidSlip"]
      ),
      MaxShearStressDeveloped: Math.round(simulateOutput[i]["MaxShearStress"]),
      ContactFaceShearStressUtilisation:
        diamondCeramic === "DiamondCeramic" ? 0 : "-",
      TreadRootShearStressUtilisation: "-",
      PulleyBondShearStressUtilisation: "-",
      TileBondShearStressUtilisation:
        diamondRubber === "DiamondRubber" ? 0 : "-",
      status: isActive ? "Active" : "Inactive",
      image: isActive ? Dimond_Rubber_Icon : Direct_Bond_Smooth,
    };

    // for (const key in obj) {
    //   if (
    //     key !== "ProductType" &&
    //     !isNaN(rowData[key]) &&
    //     parseFloat(rowData[key]) > 100
    //   ) {
    //     rowData[key] = <span style={{ color: "red" }}>{rowData[key]}</span>;
    //   }
    // }

    tableOutput.push(obj);
  }

  const getRowClassName = (record) => {
    // Define your conditions to change the background color based on the 'status' value.
    if (record.status === "Active") {
      return "active-row"; // CSS class name for active rows
    } else if (record.status === "Inactive") {
      return "inactive-row"; // CSS class name for inactive rows
    }
    // You can add more conditions for other status values if needed.
    return "";
  };
  const toggleShowSelected = (val) => {
    setShowSelected(!showSelected);
  };

  const tableFooter = (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
      }}
    >
      <label style={{ paddingRight: "10px" }}>Selection Comments</label>
      <Input
        placeholder="Type here…"
        value={commentInput}
        onChange={(e) => setCommentInput(e.target.value)}
      />

      <div>
        {showSelected ? (
          <Button
            type="text"
            onClick={() => toggleShowSelected("showMore")}
            style={{ marginLeft: "10px", color: "#F52247" }}
          >
            Show More <DownOutlined />
          </Button>
        ) : (
          reportChecked && (
            <Button
              type="text"
              onClick={() => toggleShowSelected("hide")}
              style={{ marginLeft: "10px", color: "#F52247" }}
            >
              Hide <UpOutlined />
            </Button>
          )
        )}
      </div>
    </div>
  );

  const handleRowSelect = (record) => {
    const isRowSelected = selectedRowKeys.includes(record.key);

    // If the row is already selected, deselect it
    if (isRowSelected) {
      const newSelectedRowKeys = selectedRowKeys.filter(
        (k) => k !== record.key
      );
      setSelectedRowKeys(newSelectedRowKeys);
      // Remove the deselected row from selectedRowData
      setSelectedRowData((prev) =>
        prev.filter((rowData) => rowData.key !== record.key)
      );
    } else {
      // If the row is not selected, select it
      setSelectedRowKeys((prev) => [...prev, record.key]);
      setSelectedRowData((prev) => [...prev, record]);
    }
  };

  // console.log("reportOutput", reportOutput);

  const generateReport = () => {
    // Use the selectedRowKeys to filter the selected rows from the data array
    const selectedValue = tableOutput.filter((row) =>
      selectedRowKeys.includes(row.key)
    );

    if (selectedValue.length === 0) {
      Notification.error(" Please select table data");
      setReportChecked(false);
    } else {
      setCurrent(2);
      setReportChecked(true);
      setShowSelected(true);
      Notification.success(" Report Generated successfully ");
    }
  };

  // Sample data for the multiple line chart

  return (
    <div style={{ height: "81vh", overflowY: "scroll" }}>
      <div
        style={{
          fontWeight: "bold",
          fontSize: "1rem",
          padding: "10px 0px 0px",
        }}
      >
        Statistical Output
        {/* (
          <span style={{ color: "red ", fontWeight: "bold", fontSize: "1rem" }}>
            The backend has not yet been integrated, this is a sample output of
            the dummy data.
          </span>
          ) */}
      </div>
      {simulateOutput.map((item, index) => {
        const lag = laggingInputData[index];
        console.log("item", item);
        const beltContracture = Math.round(item?.TotBltLenChg * 100) / 100;
        const T1_T2_ratio = Math.round((lag?.T1 / lag?.T2) * 100) / 100;
        const eulerEquivalentFriction =
          Math.round(item?.EulerEquiv * 100) / 100;

        const eulerUtilization = Math.round((T1_T2_ratio / item?.MaxTR) * 100);
        return (
          <div className="flex-container">
            <div>
              Belt Contracture -{" "}
              <span style={{ fontWeight: "bold" }}>{beltContracture}</span>
            </div>
            <div>
              T1 / T2 ratio -{" "}
              <span style={{ fontWeight: "bold" }}>{T1_T2_ratio}</span>
            </div>
            <div>
              Euler Utilization -{" "}
              <span style={{ fontWeight: "bold" }}>{eulerUtilization}%</span>
            </div>
            <div>
              Euler Equivalent Friction -{" "}
              <span style={{ fontWeight: "bold" }}>
                {eulerEquivalentFriction}
              </span>
            </div>
          </div>
        );
      })}

      <div>
        <Table
          columns={columns}
          dataSource={
            showSelected
              ? tableOutput.filter((item) => selectedRowKeys.includes(item.key))
              : tableOutput
          }
          bordered
          size="middle"
          scroll={{
            x: "calc(700px + 50%)",
            // y: 300,
          }}
          footer={() => tableFooter}
          rowClassName={getRowClassName}
          className="custom-header-style"
          pagination={false}
        />
      </div>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: "1.5rem 0px",
        }}
      >
        <div className="flex-container">
          <div>
            <hr className="new5" />
          </div>
          <div style={{ fontWeight: "bold" }}>Suitable Product</div>
          <div>
            <hr className="new6" />
          </div>
          <div style={{ fontWeight: "bold" }}>Not Suitable Product</div>
        </div>

        <div>
          <Button
            type="primary"
            style={{ backgroundColor: "#F52247" }}
            onClick={generateReport}
          >
            GENERATE REPORT
          </Button>
        </div>
      </div>
      <div style={{ width: "67.2vw" }}>
        {reportChecked && (
          <GenerateReport
            selectedRowKeys={selectedRowKeys}
            selectedRowData={selectedRowData}
            simulateOutput={simulateOutput}
            laggingInputData={laggingInputData}
          />
        )}
      </div>
    </div>
  );
};

export default StatisticalOutput;
