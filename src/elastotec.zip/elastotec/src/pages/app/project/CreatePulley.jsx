import React, { useState } from "react";
import { Button, Form, Input, Select } from "antd";
import axios from "axios";
import baseUrl from "src/common/baseUrl";
import Notification from "src/services/Notification";

const CreatePulley = ({
  setIsModalPulley,
  selectedProjectId,
  selectedConveyorId,
  reload,
  setReload,
}) => {
  const [form] = Form.useForm();
  const [loadings, setLoadings] = useState(false);
  const onFinish = (values) => {
    console.log("Success:", values);

    let pulleyObj = {
      PROJECT_ID: selectedProjectId,
      CONVEYOR_ID: selectedConveyorId,
      PULLEY_ID: values.pulleyId,
      PULLEY_LOCATION: values.pulleyLocation,
    };
    if (selectedConveyorId && selectedProjectId !== null) {
      setLoadings(true);
      axios
        .post(`${baseUrl}/project/createPulley`, pulleyObj)
        .then((response) => {
          console.log("Create Pully", response);
          if (response !== undefined) {
            setLoadings(false);
            Notification.success(response.data);
            setReload(!reload);
            form.resetFields();
            setIsModalPulley(false);
          }
        })
        .catch((error) => {
          console.log(error);
          Notification.error(error.response.data);
          setLoadings(false);
        });
    }
  };

  const onFinishFailed = (errorInfo) => {
    console.log("Failed:", errorInfo);
  };

  return (
    <>
      <Form
        form={form}
        name="basic"
        labelCol={{
          span: 24,
        }}
        wrapperCol={{
          span: 24,
        }}
        initialValues={{
          remember: true,
        }}
        onFinish={onFinish}
        // onFinishFailed={onFinishFailed}
        autoComplete="off"
      >
        <Form.Item
          label="Pulley Id"
          name="pulleyId"
          rules={[
            {
              required: true,
              message: "Please input your Pulley Id!",
            },
          ]}
        >
          <Input placeholder="Enter the Pulley Id" />
        </Form.Item>
        <Form.Item
          label="Pulley Location"
          name="pulleyLocation"
          rules={[
            {
              required: true,
              message: "Please select Pulley Location!",
            },
          ]}
        >
          <Select placeholder="Select the pulley location">
            <Option value="Primary Drive">Primary Drive</Option>
            <Option value="Secondary Drive">Secondary Drive</Option>
            <Option value="Gearless Drive">Gearless Drive</Option>
            <Option value="Non-Drive">Non-Drive</Option>
            <Option value="HT Bend">HT Bend</Option>
            <Option value="LT Bend">LT Bend</Option>
            <Option value="Snub">Snub</Option>
          </Select>
        </Form.Item>

        <Form.Item
          wrapperCol={{
            offset: 7,
            span: 16,
          }}
        >
          <Button
            type="primary"
            htmlType="submit"
            style={{ backgroundColor: "red", width: "60%" }}
            loading={loadings}
          >
            Submit
          </Button>
        </Form.Item>
      </Form>
    </>
  );
};

export default CreatePulley;
