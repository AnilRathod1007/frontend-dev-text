import React from "react";
import { Input } from "antd";
import "../common/CustomSearchInput.css"; // Import your custom CSS file
import { SearchOutlined } from "@ant-design/icons";

const CustomSearchInput = ({ onChange }) => {
  return (
    <div className="custom-search-input">
      <Input
        placeholder="Search"
        className="custom-input"
        // prefix={<SearchOutlined className="custom-icon" />}
        suffix={<SearchOutlined className="custom-icon" />}
        onChange={onChange}
      />
    </div>
  );
};

export default CustomSearchInput;
