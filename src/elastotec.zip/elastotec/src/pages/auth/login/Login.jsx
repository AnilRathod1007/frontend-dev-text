import React, { useEffect, useState } from "react";
import {
  ArrowLeftOutlined,
  LockOutlined,
  UserOutlined,
} from "@ant-design/icons";
import { Button, Checkbox, Form, Input, Card, Row } from "antd";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import Elastotec_logo from "src/assets/Elastotec_logo.png";
import Lagging_Select_logo from "src/assets/Lagging_Select_logo.png";
import Conveyor_dynamics_logo from "src/assets/Conveyor_dynamics_logo.png";
import AppStore from "src/store/AppStore";
import Notification from "src/services/Notification";
import Api from "src/services/Api";
import "./Styles.css";

const LoginForm = ({ onFinish, onFinishFailed }) => {
  return (
    <Form
      name="normal_login"
      className="login-form"
      initialValues={{
        remember: true,
      }}
      labelCol={{
        span: 24,
      }}
      wrapperCol={{
        span: 24,
      }}
      onFinish={onFinish}
      onFinishFailed={onFinishFailed}
    >
      <label className="login-label">EMAIL ID</label>
      <Form.Item
        // label="EMAIL ID"
        name="username"
        rules={[
          {
            required: true,
            message: "Please input your Email ID!",
          },
        ]}
      >
        <Input
          prefix={<UserOutlined className="site-form-item-icon" />}
          placeholder="Enter email ID"
        />
      </Form.Item>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: "2px",
        }}
      >
        <label className="login-label">PASSWORD</label>
        <span style={{ color: "#F52247" }}>Forgot password?</span>
      </div>

      <Form.Item
        name="password"
        rules={[
          {
            required: true,
            message: "Please input your Password!",
          },
        ]}
        style={{ marginBottom: "0px" }}
      >
        <Input
          prefix={<LockOutlined className="site-form-item-icon" />}
          type="password"
          placeholder="Enter Password"
        />
      </Form.Item>

      <Form.Item>
        <Form.Item name="remember" valuePropName="checked" noStyle>
          <Checkbox className="custom-checkbox">I agree with the </Checkbox>
        </Form.Item>
        <span style={{ color: "#F52247", textDecoration: "underline" }}>
          Terms and Conditions*
        </span>
      </Form.Item>

      <Form.Item>
        <Button
          type="primary"
          htmlType="submit"
          style={{ width: "100%", backgroundColor: "#F52247" }}
        >
          NEXT
        </Button>
        {/* Or <a href="">register now!</a> */}
      </Form.Item>
    </Form>
  );
};

const Login = () => {
  const navigate = useNavigate();
  const baseUrl = "https://auth.cvthold.com/api";

  const [isWideScreen, setIsWideScreen] = useState(window.innerWidth > 650);
  const [login, setLogin] = AppStore("login");
  const [loginToken, setLoginToken] = AppStore("token");

  const [checked, setChecked] = useState(false);
  const [loadings, setLoadings] = useState(false);

  const onFinish = (values) => {
    console.log("Received values of form: ", values);
    setLogin(values);
  };

  const onFinishFailed = (errorInfo) => {
    console.log("Form validation failed:", errorInfo);
  };

  useEffect(() => {
    const handleResize = () => {
      setIsWideScreen(window.innerWidth > 650);
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  const onChange = (e) => {
    console.log(`checked = ${e.target.checked}`);
    setChecked(e.target.checked);
  };

  const onLogin = () => {
    // console.log("login", login);

    const { username, password } = login;

    if (checked) {
      setLoadings(true);
      axios
        .post(`${baseUrl}/login/authenticate`, {
          username: username,
          password: password,
        })
        .then((response) => {
          const token = response.data;
          if (token.err !== undefined) {
            console.log(token.err);
          } else {
            setLoginToken(token.token);
            Api.header(token.token);
            navigate("/project");
            Notification.success("You are successfully logged in");
            setLoadings(false);
          }
        })
        .catch((error) => {
          Notification.error(
            "Login Failed, Please Enter Correct UserName & Password"
          );
          setLoadings(false);
        });
    } else {
      Notification.error("Please Select Terms and Conditions");
    }
  };

  const onBack = () => {
    setLogin("");
    setLoginToken("");
  };

  return (
    <>
      {isWideScreen ? (
        <>
          <div className="header-container">
            <img src={Elastotec_logo} alt="Elastotec" className="header-logo" />
            <hr className="logo-divider" />
            {/* <img src={path} alt="path" className="header-logo-line" /> */}
            <img
              src={Lagging_Select_logo}
              alt="Lagging Select"
              className="header-logo1"
            />
            <hr className="logo-divider" />
            {/* <img src={path} alt="path" className="header-logo-line" /> */}
            <img
              src={Conveyor_dynamics_logo}
              alt="Conveyor Dynamics"
              className="header-logo"
            />
          </div>
        </>
      ) : (
        <>
          <div className="header-container">
            <img src={Elastotec_logo} alt="Elastotec" className="header-logo" />
            <hr className="logo-divider" />
            {/* <img src={path} alt="path" className="header-logo" /> */}

            <img
              src={Lagging_Select_logo}
              alt="Lagging Select"
              className="header-logo1"
            />
          </div>
        </>
      )}

      <Row className="login-main">
        <Card className="card">
          {!login?.username ? (
            <>
              <p className="login-lagging">
                Sign in to <span className="lagging">lagging</span>Select{" "}
                <span style={{ color: "#F52247", fontWeight: "bold" }}>!</span>
              </p>
              <p style={{ margin: "0px 0px 2rem 0px", color: "#6F6F6F" }}>
                Sign in using your official email ID.
              </p>
              <LoginForm onFinish={onFinish} onFinishFailed={onFinishFailed} />
            </>
          ) : (
            <>
              <Button
                type="link"
                icon={<ArrowLeftOutlined />}
                style={{
                  color: "#F52247",
                  padding: "0px",
                  margin: "-20px 0px 0px -20px",
                }}
                onClick={onBack}
              >
                Back
              </Button>
              <div>
                <p
                  style={{
                    fontSize: "1.5rem",
                    fontWeight: "normal",
                    color: "#070E03",
                    margin: "13px 0px",
                  }}
                >
                  Consent <span style={{ color: "#F52247" }}>!</span>
                </p>
                <p
                  style={{
                    fontSize: "0.92rem",
                    fontWeight: "normal",
                    color: "#070E03",
                  }}
                >
                  “ EACH ANALYSIS PERFORMED IN LAGGING SELECT IS SPECIFIC TO
                  <span style={{ color: "#F52247" }}>
                    {" "}
                    ELASTOTEC PRODUCTS
                  </span>{" "}
                  ONLY. THE RESULTS ARE NOT TRANSFERABLE TO OTHER LAGGING
                  BRANDS, AND THE USE OF AN ALTERNATIVE LAGGING BRAND MAY LEAD
                  TO A
                  <span style={{ color: "#F52247" }}>
                    {" "}
                    BELT/LAGGING FAILURE
                  </span>{" "}
                  ”
                </p>
                <div>
                  <Checkbox onChange={onChange} className="custom-checkbox">
                    Yes, I agree with the
                  </Checkbox>
                  <span style={{ color: "#F52247" }}>consent*</span>
                </div>
                <div style={{ padding: "2.5rem 0px 0px 0px" }}>
                  <Button
                    type="primary"
                    style={{
                      width: "100%",
                      backgroundColor: "#F52247",
                    }}
                    loading={loadings}
                    onClick={onLogin}
                  >
                    SIGN IN
                  </Button>
                </div>
              </div>
            </>
          )}
        </Card>
      </Row>
    </>
  );
};

export default Login;
