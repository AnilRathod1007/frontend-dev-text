import { Button, Col, Row, Steps } from "antd";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import back from "src/assets/back.png";
import AppStore from "src/store/AppStore";

const AnalyesHeader = ({
  current,
  setCurrent,
  setLaggingInputData,
  setSimulateOutput,
}) => {
  const navigate = useNavigate();
  const [selectedPulleyId, setSelectedPulleyId] = AppStore("pulleyId");
  const [projectName, setProjectName] = AppStore("projectName");
  const [selectedConveyorId, setSelectedConveyorId] = AppStore("conveyorId");

  const onBack = () => {
    setLaggingInputData("");
    setSimulateOutput("");
    setSelectedPulleyId(null);
    setSelectedConveyorId(null);

    setProjectName("");
    navigate("/project");
  };

  const next = () => {
    setCurrent(current + 1);
  };

  return (
    <>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          paddingBottom: "0.4rem",
        }}
      >
        <div>
          <Button type="text" onClick={onBack}>
            <img src={back} alt="Back" />
          </Button>
        </div>
        <div>
          <Steps
            id="mySteps"
            size="small"
            current={current}
            items={[
              {
                title: "Lagging Select Details",
              },
              {
                title: "Results",
              },
            ]}
          />
        </div>
        <div></div>
      </div>
    </>
  );
};

export default AnalyesHeader;
