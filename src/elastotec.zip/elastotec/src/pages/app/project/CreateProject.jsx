import React, { useState } from "react";
import { Button, Form, Input, Select } from "antd";
import axios from "axios";
import baseUrl from "src/common/baseUrl";
import Notification from "src/services/Notification";

const CreateProject = ({ reload, setReload, handleOk }) => {
  const [form] = Form.useForm();
  const [loadings, setLoadings] = useState(false);

  const onFinish = (values) => {
    console.log("Success:", values);
    const obj = {
      PROJECT_NAME: values.projectName,
      PROJECT_LOCATION: values.projectLocation,
      LAGGING_REPLACEMENT: values.laggingReplacement,
    };
    setLoadings(true);
    axios
      .post(`${baseUrl}/project/createProject`, obj)
      .then((response) => {
        if (response !== undefined) {
          console.log("Create Project", response);
          setLoadings(false);
          Notification.success(response.data);
          handleOk();
          setReload(!reload);
          form.resetFields();
        }
      })
      .catch((error) => {
        console.log(error);
        Notification.error(error.response.data);
        setLoadings(false);
      });
  };
  const onFinishFailed = (errorInfo) => {
    console.log("Failed:", errorInfo);
  };
  return (
    <>
      <Form
        form={form}
        name="basic"
        labelCol={{
          span: 24,
        }}
        wrapperCol={{
          span: 24,
        }}
        initialValues={{
          remember: true,
        }}
        onFinish={onFinish}
        // onFinishFailed={onFinishFailed}
        autoComplete="off"
      >
        <Form.Item
          label="Project Name"
          name="projectName"
          rules={[
            {
              required: true,
              message: "Please input your Project Name!",
            },
          ]}
        >
          <Input placeholder="Enter the project name" />
        </Form.Item>

        <Form.Item
          label="Project Location"
          name="projectLocation"
          rules={[
            {
              required: true,
              message: "Please input your Project Location!",
            },
          ]}
        >
          <Input placeholder="Enter the project location" />
        </Form.Item>
        <Form.Item
          label="Lagging Replacement (Reason)"
          name="laggingReplacement"
          rules={[
            {
              required: true,
              message: "Please select Lagging Replacement!",
            },
          ]}
        >
          <Select placeholder="Select reason">
            <Option value="New Project">New Project</Option>
            <Option value="Conveyor Design Upgrade / Change">
              Conveyor Design Upgrade / Change
            </Option>
            <Option value="other">Other</Option>
          </Select>
        </Form.Item>

        <Form.Item
          wrapperCol={{
            offset: 7,
            span: 16,
          }}
        >
          <Button
            type="primary"
            htmlType="submit"
            style={{ backgroundColor: "red", width: "60%" }}
            loading={loadings}
          >
            Submit
          </Button>
        </Form.Item>
      </Form>
    </>
  );
};

export default CreateProject;
