import { useState } from "react";
import {
  Route,
  RouterProvider,
  createBrowserRouter,
  createRoutesFromElements,
} from "react-router-dom";
import "./App.css";
import Login from "./pages/auth/login/Login";
import AuthLayout from "./common/layout/AuthLayout";
import Project from "./pages/app/project/Project";
import Analyes from "./pages/app/analyes/Analyes";

function App() {
  const router = createBrowserRouter(
    createRoutesFromElements(
      <>
        <Route path="/" element={<Login />} />
        {/* <Route path="forgotpassword" element={<ForgotPassword />} />
        <Route path="register" element={<Register />} /> */}
        <Route element={<AuthLayout />}>
          <Route path="project" element={<Project />} />
          <Route path="analyes" element={<Analyes />} />
        </Route>
      </>
    )
  );
  return (
    <>
      <RouterProvider router={router} />
    </>
  );
}

export default App;
