import { Input } from 'antd';
import React from 'react'


const CustomInputField = ({ value, label, name, placeholder, type, onChange,  }) => (
  <>
    <div className="form-group">
      {label && <label htmlFor="input-field" style={{display: 'flex'}}>{label}</label>}
      <Input
        value={value}
        placeholder={placeholder}
        name={name}
        type={type}
        onChang={onChange}
      />


    </div>
  </>
)


export default CustomInputField;