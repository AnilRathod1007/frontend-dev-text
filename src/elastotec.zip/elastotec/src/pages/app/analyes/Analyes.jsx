import { Col, Row } from "antd";
import React, { useEffect, useState } from "react";
import AppStore from "src/store/AppStore";
import AnalyesHeader from "./AnalyesHeader";
import LaggingOperating from "./LaggingOperating";
import StatisticalOutput from "./StatisticalOutput";
import PageLoader from "src/common/PageLoader";

const Analyes = () => {
  const [laggingInputData, setLaggingInputData] = AppStore("lagging");
  const [pageLoader, setPageLoader] = useState(false);
  const [simulateOutput, setSimulateOutput] = AppStore("simulate");

  const [current, setCurrent] = useState(0);
  return (
    <div style={{ padding: "1rem" }}>
      <Row gutter={[16, 16]}>
        <Col span={24}>
          <AnalyesHeader
            current={current}
            setCurrent={setCurrent}
            setLaggingInputData={setLaggingInputData}
            setSimulateOutput={setSimulateOutput}
          />
        </Col>
      </Row>
      <Row gutter={[16, 16]}>
        <Col
          xl={{ span: 7 }}
          lg={{ span: 7 }}
          md={{ span: 7 }}
          sm={{ span: 24 }}
          xs={{ span: 24 }}
        >
          <LaggingOperating
            current={current}
            setCurrent={setCurrent}
            laggingInputData={laggingInputData}
            setLaggingInputData={setLaggingInputData}
            simulateOutput={simulateOutput}
            setSimulateOutput={setSimulateOutput}
          />
        </Col>
        <Col
          // span={17}
          xl={{ span: 17 }}
          lg={{ span: 17 }}
          md={{ span: 17 }}
          sm={{ span: 24 }}
          xs={{ span: 24 }}
        >
          {simulateOutput.length > 0 && (
            <StatisticalOutput
              current={current}
              setCurrent={setCurrent}
              simulateOutput={simulateOutput}
              setSimulateOutput={setSimulateOutput}
              laggingInputData={laggingInputData}
            />
          )}
        </Col>
      </Row>
      <PageLoader visible={pageLoader} />
    </div>
  );
};

export default Analyes;
