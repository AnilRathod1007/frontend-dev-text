import create from "zustand";
import { persist } from "zustand/middleware";

import CryptoJS from "crypto-js";

const secretKey = "Elastotec@1010";

// Encryption functions
function encrypt(value) {
  const jsonString = JSON.stringify(value);
  return CryptoJS.AES.encrypt(jsonString, secretKey).toString();
}

function decrypt(encryptedData) {
  const bytes = CryptoJS.AES.decrypt(encryptedData, secretKey);
  return JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
}

function process(set, state) {
  for (const key in state) {
    state["set" + key] = function (value) {
      set((state) => {
        state[key] = value;
      });
    };
  }
  return state;
}

function store(state) {
  const getStore = create(
    persist(
      (set) => {
        return process(set, state);
      },
      {
        name: "myAppStorage", // Specify a unique name for your storage
        onRehydrate: () => {
          // Optional callback when data is read from storage
          // You can perform actions here after data is loaded
        },
        // serialize: (data) => {
        //   // Encrypt and stringify the data before saving it to localStorage
        //   const serializedData = {};
        //   for (const key in data) {
        //     if (key !== "clearPersistedData") {
        //       serializedData[key] = encrypt(data[key]);
        //     }
        //   }
        //   return JSON.stringify(serializedData);
        // },
        // deserialize: (data) => {
        //   // Parse and decrypt the data when reading it from localStorage
        //   const parsedData = JSON.parse(data);
        //   const decryptedData = {};
        //   for (const key in parsedData) {
        //     if (key !== "clearPersistedData") {
        //       const encryptedData = parsedData[key];
        //       if (encryptedData) {
        //         decryptedData[key] = decrypt(encryptedData);
        //       }
        //     }
        //   }
        //   return decryptedData;
        // },
      }
    )
  );
  const storeFactory = function (key) {
    return [
      getStore((state) => state[key]),
      getStore((state) => state["set" + key]),
    ];
  };
  storeFactory.getState = getStore.getState;
  storeFactory.setState = getStore.setState;

  // Function to clear the persisted data
  storeFactory.clearPersistedData = () => {
    localStorage.removeItem("myAppStorage"); // Replace with your storage name
  };
  return storeFactory;
}

export default store;
