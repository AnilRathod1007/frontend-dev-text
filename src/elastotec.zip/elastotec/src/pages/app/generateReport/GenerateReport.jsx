import { Button, Col, Row, Space } from "antd";
import React, { useState, useEffect } from "react";
import LineChart from "src/common/charts/LineChart";
import path from "src/assets/path66.png";
import "../generateReport/Styles.css";
import { useNavigate } from "react-router-dom";

const GenerateReport = ({
  selectedRowKeys,
  selectedRowData,
  simulateOutput,
  laggingInputData,
}) => {
  const navigate = useNavigate();

  const [reportOutput, setReportOutput] = useState([]);
  const [laggingInput, setLaggingInput] = useState([]);

  useEffect(() => {
    const filteredData = selectedRowKeys.map((item) => simulateOutput[item]);
    setReportOutput(filteredData);
    const laggingFilteredData = selectedRowKeys.map(
      (item) => laggingInputData[item]
    );
    setLaggingInput(laggingFilteredData);
  }, [selectedRowKeys]);
  console.log("reportOutput", reportOutput);
  console.log("laggingInput", laggingInput);

  // const chartData1 = [
  //   {
  //     x: [1, 2, 3, 4, 5],
  //     y: [0, 0, 0, 0, 0], // Baseline data
  //     connectgaps: true,
  //     mode: "lines",
  //     name: "Baseline",
  //     type: "scatter",
  //     line: { color: "transparent" },
  //     showlegend: false,
  //   },
  //   {
  //     x: [1, 2, 3, 4, 5],
  //     y: [15, 15, 15, 15, 15],
  //     connectgaps: true,
  //     fill: "tonexty",
  //     fillcolor: "rgba(167, 252, 182, 0.3)",
  //     mode: "none", // 'none' to hide the line
  //     name: "Safe Zone",
  //     showlegend: false,
  //     type: "scatter",
  //   },
  //   {
  //     x: [1, 2, 3, 4, 5],
  //     y: [1, 7, 5.5, 2.5, 0, 0],
  //     connectgaps: true,
  //     fill: "tonexty",
  //     fillcolor: "rgba(255, 161, 161, 0.6)",
  //     mode: "none", // 'none' to hide the line
  //     name: "Risk Zone",
  //     showlegend: false,
  //     type: "scatter",
  //     line: {
  //       shape: "spline", // Set line shape to "spline" for rounded ends
  //     },
  //   },
  //   {
  //     x: [1, 2, 3, 4, 5],
  //     y: [12, 13, 10, 9, 11],
  //     connectgaps: true,
  //     mode: "lines",
  //     name: "Line 1",
  //     type: "scatter",
  //     line: {
  //       color: "blue", // Optionally specify the line color
  //     },
  //   },
  //   {
  //     x: [1, 2, 3, 4, 5],
  //     y: [null, 5, 5.5, 3.5],
  //     connectgaps: true,
  //     mode: "lines",
  //     name: "Line",
  //     type: "scatter",
  //     line: {
  //       width: 4, // Specify the line thickness here
  //       color: "black", // Optionally specify the line color
  //     },
  //   },
  //   {
  //     x: [1, 2, 3, 4, 5],
  //     y: [7, 8, 12, 10, 6],
  //     connectgaps: true,
  //     mode: "lines",
  //     name: "Line 2",
  //     type: "scatter",
  //     line: {
  //       color: "red", // Optionally specify the line color
  //     },
  //     //  fill: 'tozeroy',
  //   },

  //   {
  //     x: [1, 2, 3, 4, 5],
  //     y: [8, 5, 12, 13, 14],
  //     connectgaps: true,
  //     mode: "lines",
  //     name: "Line 3",
  //     line: {
  //       color: "green", // Optionally specify the line color
  //     },
  //   },
  //   {
  //     x: [1, 2, 3, 4, 5],
  //     y: [1, 5, 9, 6, 3],
  //     connectgaps: true,
  //     mode: "lines",
  //     line: { dash: "dash", color: "red" }, // Use the dash property to create a dashed line
  //     name: "Dashed Line",
  //   },
  // ];

  const newChartData = [
    {
      x: [1, 2, 3, 4, 5],
      y: [1, 3, 5, 7, 3],
      connectgaps: true,
      mode: "lines",
      name: "Line 1",
      type: "scatter",
      line: {
        color: "blue",
      },
    },
    {
      x: [1, 2, 3, 4, 5],
      y: [2, 1, 4, 2],
      connectgaps: true,
      mode: "lines",
      name: "Line",
      type: "scatter",
      line: {
        color: "orange",
      },
    },
    {
      x: [1, 2, 3, 4, 5],
      y: [12, 4, 6, 7, 9],
      connectgaps: true,
      mode: "lines",
      name: "Line 2",
      type: "scatter",
      // fill: "tozeroy", // Fill area below the line
      // fill: "tonexty", // Fill area above the line
      line: {
        color: "green",
      },
    },

    {
      x: [1, 2, 3, 4, 5],
      y: [14, 12, 13, 5, 1],
      connectgaps: true,
      mode: "lines",
      name: "Line 3",
      line: {
        color: "red",
      },
    },
    {
      x: [1, 2, 3, 4, 5],
      y: [11, 12, 9, 3, 13],
      connectgaps: true,
      mode: "lines",
      line: { dash: "dash", color: "#9B59B6" },
      name: "Dashed Line",
    },
  ];

  return (
    <>
      <div>
        <div
          style={{
            fontWeight: "bold",
            padding: "10px 0",
          }}
        >
          Graphical Output
        </div>

        {reportOutput?.map((item, index) => {
          // console.log("item", item);
          const lag = laggingInput[index];

          const chartData = [
            {
              x: item?.WrapPos,
              y: item?.ShearStress,
              connectgaps: true,
              mode: "lines",
              name: "Shear Stress(kPa)",
              type: "scatter",
              line: {
                color: "blue",
              },
            },

            {
              x: item?.WrapPos,
              y: item?.ContactPressure,
              connectgaps: true,
              mode: "lines",
              name: "Contact Pressure(kPa)",
              type: "scatter",
              line: {
                color: "black",
              },
            },
          ];
          const secondaryChartData = [
            // {
            //   y: item?.FricDev,
            //   x: item?.WrapPos,
            //   type: "scatter",
            //   mode: "none",
            //   name: "Friction Factor (μ)",
            //   fill: "toself",
            //   fillcolor: "rgba(255, 0, 0, 0.3)",
            //   yaxis: "y2",
            //   showlegend: false,
            //   connectgaps: true,
            //   line: {
            //     color: "orange",
            //   },
            // },
            {
              x: item?.WrapPos,
              y: item?.FricDev,
              type: "scatter",
              mode: "lines",
              name: "Developed Friction",
              yaxis: "y2",
              connectgaps: true,
              line: {
                color: "red",
              },
            },
            {
              x: item?.WrapPos,
              y: item?.FricDry,
              type: "scatter",
              mode: "lines",
              name: "Clean/Dry Limit(μ)",
              yaxis: "y2",
              connectgaps: true,
              line: {
                color: "red",
                dash: "dash",
              },
            },
            {
              x: item?.WrapPos,
              y: item?.FricWet,
              type: "scatter",
              mode: "lines",
              name: "Wet/Dirty Friction Limit(μ)",
              yaxis: "y2",
              connectgaps: true,
              line: {
                color: "green",
                dash: "dash",
              },
            },
          ];

          const laggingEnvelope = [
            // {
            //   x: item?.AvgNormPress,
            //   y: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.0, 0, 0, 0, 0], // Baseline data
            //   connectgaps: true,
            //   mode: "lines",
            //   name: "Baseline",
            //   type: "scatter",
            //   line: { color: "transparent" },
            //   showlegend: false,
            // },
            // {
            //   x: item?.AvgNormPress,
            //   y: [
            //     350, 350, 350, 350, 350, 350, 350, 350, 350, 350, 350, 350, 350,
            //     350, 350,
            //   ],
            //   connectgaps: true,
            //   fill: "tonexty",
            //   fillcolor: "rgba(167, 252, 182, 0.3)",
            //   mode: "none", // 'none' to hide the line
            //   name: "Safe Zone",
            //   // showlegend: false,
            //   type: "scatter",
            // },
            // {
            //   x: [
            //     0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130, 140,
            //     150, 160, 170, 180, 190, 200, 210, 220, 230, 240, 250, 260, 270,
            //     280, 290, 300, 310, 320, 330, 340, 350, 360, 370, 380, 390, 400,
            //     410, 420, 430, 440, 450, 460, 470, 480, 490, 500, 510, 520, 530,
            //     540, 550, 560, 570, 580, 590, 600, 610, 620, 630, 640, 650, 660,
            //     670, 680, 690, 700, 710, 720, 730, 740, 750, 760, 770, 780, 790,
            //     800,
            //   ],
            //   y: [
            //     0, 12, 24, 36, 48, 60, 72, 84, 96, 108, 120, 122, 124, 126, 128,
            //     130, 132, 134, 136, 138, 140, 143, 146, 149, 152, 155, 158, 161,
            //     164, 167, 170, 172, 174, 176, 178, 180, 182, 184, 186, 188, 190,
            //     196, 202, 208, 214, 220, 226, 232, 238, 244, 250, 243, 236, 229,
            //     222, 215, 208, 201, 194, 187, 180, 178, 176, 174, 172, 170, 168,
            //     166, 164, 162, 160, 158, 156, 154, 152, 150, 148, 146, 144, 142,
            //     140,
            //   ],
            //   connectgaps: true,
            //   fill: "tonexty",
            //   fillcolor: "rgba(255, 161, 161, 0.6)",
            //   mode: "none", // 'none' to hide the line
            //   name: "Risk Zone",
            //   // showlegend: true,
            //   type: "scatter",
            //   line: {
            //     shape: "spline", // Set line shape to "spline" for rounded ends
            //   },
            // },

            {
              x: item?.ContactPressure,
              y: item?.ShearStress,
              connectgaps: true,
              mode: "lines+markers", // Set the mode to 'markers' for a scatter plot
              type: "scatter",
              name: "Application Duty",

              line: {
                width: 2,
                color: "black",
              },
            },

            {
              x: item?.AvgNormPress,
              y: item?.TreadRootLim,
              connectgaps: true,
              mode: "scatter",
              type: "scatter",

              name: "Tread Root Limit",
              line: {
                color: "orange",
              },
            },
            {
              x: item?.AvgNormPress,
              y: item?.PullShellLim,
              connectgaps: true,
              mode: "scatter",
              name: "Pulley Shell Limit",
              type: "lines",
              line: {
                color: "yellow",
              },
            },
            {
              x: item?.AvgNormPress,
              y: item?.TileBondLim,
              connectgaps: true,
              mode: "scatter",
              type: "lines",

              name: "Tile Bond Limit",
              line: {
                color: "#800080",
              },
            },

            {
              x: item?.AvgNormPress,
              y: item?.ContFaceLim,
              connectgaps: true,
              mode: "scatter",
              name: "Contact Face Limit",
              type: "scatter",
              line: {
                color: "blue",
              },
            },

            {
              x: item?.AvgNormPress,
              y: item?.ShearStressWet,
              connectgaps: true,
              mode: "lines",
              name: "Avail. Driving Shear Stress-Wet Dirty",
              line: { dash: "dash", color: "green" },
            },
            {
              x: item?.AvgNormPress,
              y: item?.ShearStressDry,
              connectgaps: true,
              mode: "lines",
              name: "Avail. Driving Shear Stress-Dry Clean",
              line: { dash: "dash", color: "red" },
            },
          ];

          const pulleyLagging = chartData.concat(secondaryChartData);
          return (
            <div key={index}>
              <div
                style={{ fontWeight: "500" }}
              >{`${lag?.LagEnv?.Product}, ${lag?.LagEnv?.Thk} mm, ${lag?.LagEnv?.Duro} mm`}</div>

              <Row key={index} gutter={[16, 16]}>
                <Col
                  xl={{ span: 12 }}
                  lg={{ span: 12 }}
                  md={{ span: 24 }}
                  sm={{ span: 24 }}
                  xs={{ span: 24 }}
                >
                  <div
                    style={{
                      padding: "10px 0",
                      fontWeight: "500",
                    }}
                  >
                    Friction Analysis
                  </div>
                  <LineChart
                    data={pulleyLagging}
                    yLabel={"Normal Pressure/Shear Stress(kPa)"}
                    xLabel={"Wrap Position(deg.)"}
                    yLabel2={"Friction Factor (μ)"}
                  />
                </Col>
                <Col
                  xl={{ span: 12 }}
                  lg={{ span: 12 }}
                  md={{ span: 24 }}
                  sm={{ span: 24 }}
                  xs={{ span: 24 }}
                >
                  <div
                    style={{
                      padding: "10px 0",
                      fontWeight: "500",
                    }}
                  >
                    Fatigue Analysis
                  </div>
                  <LineChart
                    data={laggingEnvelope}
                    yLabel={"Average Shear Stress(kPa)"}
                    xLabel={"Normal Pressure(kPa)"}
                    // tickvals={item}
                  />
                </Col>
              </Row>
              {index !== reportOutput?.length - 1 && (
                <img src={path} alt="path" className="img-line" />
              )}
            </div>
          );
        })}
      </div>
      <div
        style={{
          display: "flex",
          justifyContent: "end",
          padding: "1rem 0",
        }}
      >
        <Space>
          <Button
            type="text"
            style={{
              color: "#F52247",
            }}
            onClick={() => navigate("/project")}
          >
            <span style={{ textDecoration: "underline" }}>
              Go Back To Explorer
            </span>{" "}
          </Button>
          <Button
            type="primary"
            style={{
              backgroundColor: "#070E03",
            }}
          >
            DOWNLOAD
          </Button>
        </Space>
      </div>
    </>
  );
};

export default GenerateReport;
